package androidx.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/* renamed from: androidx.multidex.b */
/* loaded from: classes.dex */
final class C0072b implements Closeable {

    /* renamed from: d */
    private final File f150d;

    /* renamed from: e */
    private final long f151e;

    /* renamed from: f */
    private final File f152f;

    /* renamed from: g */
    private final RandomAccessFile f153g;

    /* renamed from: h */
    private final FileChannel f154h;

    /* renamed from: i */
    private final FileLock f155i;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: androidx.multidex.b$a */
    /* loaded from: classes.dex */
    public class C0073a implements FileFilter {
        C0073a(C0072b c0072b) {
        }

        @Override // java.io.FileFilter
        public boolean accept(File file) {
            return !file.getName().equals("MultiDex.lock");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.multidex.b$b */
    /* loaded from: classes.dex */
    public static class C0074b extends File {

        /* renamed from: d */
        public long f156d;

        public C0074b(File file, String str) {
            super(file, str);
            this.f156d = -1L;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public C0072b(File file, File file2) {
        Log.i("MultiDex", "MultiDexExtractor(" + file.getPath() + ", " + file2.getPath() + ")");
        this.f150d = file;
        this.f152f = file2;
        this.f151e = m2560f(file);
        File file3 = new File(file2, "MultiDex.lock");
        RandomAccessFile randomAccessFile = new RandomAccessFile(file3, "rw");
        this.f153g = randomAccessFile;
        try {
            FileChannel channel = randomAccessFile.getChannel();
            this.f154h = channel;
            try {
                Log.i("MultiDex", "Blocking on lock " + file3.getPath());
                this.f155i = channel.lock();
                Log.i("MultiDex", file3.getPath() + " locked");
            } catch (IOException e) {
                e = e;
                m2564b(this.f154h);
                throw e;
            } catch (Error e2) {
                e = e2;
                m2564b(this.f154h);
                throw e;
            } catch (RuntimeException e3) {
                e = e3;
                m2564b(this.f154h);
                throw e;
            }
        } catch (IOException | Error | RuntimeException e4) {
            m2564b(this.f153g);
            throw e4;
        }
    }

    /* renamed from: a */
    private void m2565a() {
        File[] listFiles = this.f152f.listFiles(new C0073a(this));
        if (listFiles == null) {
            Log.w("MultiDex", "Failed to list secondary dex dir content (" + this.f152f.getPath() + ").");
            return;
        }
        for (File file : listFiles) {
            Log.i("MultiDex", "Trying to delete old file " + file.getPath() + " of size " + file.length());
            if (!file.delete()) {
                Log.w("MultiDex", "Failed to delete old file " + file.getPath());
            } else {
                Log.i("MultiDex", "Deleted old file " + file.getPath());
            }
        }
    }

    /* renamed from: b */
    private static void m2564b(Closeable closeable) {
        try {
            closeable.close();
        } catch (IOException e) {
            Log.w("MultiDex", "Failed to close resource", e);
        }
    }

    /* renamed from: c */
    private static void m2563c(ZipFile zipFile, ZipEntry zipEntry, File file, String str) {
        InputStream inputStream = zipFile.getInputStream(zipEntry);
        File createTempFile = File.createTempFile("tmp-" + str, ".zip", file.getParentFile());
        Log.i("MultiDex", "Extracting " + createTempFile.getPath());
        try {
            ZipOutputStream zipOutputStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(createTempFile)));
            ZipEntry zipEntry2 = new ZipEntry("classes.dex");
            zipEntry2.setTime(zipEntry.getTime());
            zipOutputStream.putNextEntry(zipEntry2);
            byte[] bArr = new byte[16384];
            while (true) {
                int read = inputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                zipOutputStream.write(bArr, 0, read);
            }
            zipOutputStream.closeEntry();
            zipOutputStream.close();
            if (!createTempFile.setReadOnly()) {
                throw new IOException("Failed to mark readonly \"" + createTempFile.getAbsolutePath() + "\" (tmp of \"" + file.getAbsolutePath() + "\")");
            }
            Log.i("MultiDex", "Renaming to " + file.getPath());
            if (createTempFile.renameTo(file)) {
                return;
            }
            throw new IOException("Failed to rename \"" + createTempFile.getAbsolutePath() + "\" to \"" + file.getAbsolutePath() + "\"");
        } finally {
            m2564b(inputStream);
            createTempFile.delete();
        }
    }

    /* renamed from: d */
    private static SharedPreferences m2562d(Context context) {
        return context.getSharedPreferences("multidex.version", Build.VERSION.SDK_INT < 11 ? 0 : 4);
    }

    /* renamed from: e */
    private static long m2561e(File file) {
        long lastModified = file.lastModified();
        return lastModified == -1 ? lastModified - 1 : lastModified;
    }

    /* renamed from: f */
    private static long m2560f(File file) {
        long m2552c = C0075c.m2552c(file);
        return m2552c == -1 ? m2552c - 1 : m2552c;
    }

    /* renamed from: g */
    private static boolean m2559g(Context context, File file, long j, String str) {
        SharedPreferences m2562d = m2562d(context);
        if (m2562d.getLong(str + "timestamp", -1L) == m2561e(file)) {
            if (m2562d.getLong(str + "crc", -1L) == j) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: i */
    private List<C0074b> m2557i(Context context, String str) {
        Log.i("MultiDex", "loading existing secondary dex files");
        String str2 = this.f150d.getName() + ".classes";
        SharedPreferences m2562d = m2562d(context);
        int i = m2562d.getInt(str + "dex.number", 1);
        ArrayList arrayList = new ArrayList(i + (-1));
        int i2 = 2;
        while (i2 <= i) {
            C0074b c0074b = new C0074b(this.f152f, str2 + i2 + ".zip");
            if (!c0074b.isFile()) {
                throw new IOException("Missing extracted secondary dex file '" + c0074b.getPath() + "'");
            }
            c0074b.f156d = m2560f(c0074b);
            long j = m2562d.getLong(str + "dex.crc." + i2, -1L);
            long j2 = m2562d.getLong(str + "dex.time." + i2, -1L);
            long lastModified = c0074b.lastModified();
            if (j2 == lastModified) {
                String str3 = str2;
                SharedPreferences sharedPreferences = m2562d;
                if (j == c0074b.f156d) {
                    arrayList.add(c0074b);
                    i2++;
                    m2562d = sharedPreferences;
                    str2 = str3;
                }
            }
            throw new IOException("Invalid extracted dex: " + c0074b + " (key \"" + str + "\"), expected modification time: " + j2 + ", modification time: " + lastModified + ", expected crc: " + j + ", file crc: " + c0074b.f156d);
        }
        return arrayList;
    }

    /* renamed from: j */
    private List<C0074b> m2556j() {
        boolean z;
        String str = this.f150d.getName() + ".classes";
        m2565a();
        ArrayList arrayList = new ArrayList();
        ZipFile zipFile = new ZipFile(this.f150d);
        try {
            ZipEntry entry = zipFile.getEntry("classes2.dex");
            int i = 2;
            while (entry != null) {
                C0074b c0074b = new C0074b(this.f152f, str + i + ".zip");
                arrayList.add(c0074b);
                Log.i("MultiDex", "Extraction is needed for file " + c0074b);
                int i2 = 0;
                boolean z2 = false;
                while (i2 < 3 && !z2) {
                    int i3 = i2 + 1;
                    m2563c(zipFile, entry, c0074b, str);
                    try {
                        c0074b.f156d = m2560f(c0074b);
                        z = true;
                    } catch (IOException e) {
                        Log.w("MultiDex", "Failed to read crc from " + c0074b.getAbsolutePath(), e);
                        z = false;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append("Extraction ");
                    sb.append(z ? "succeeded" : "failed");
                    sb.append(" '");
                    sb.append(c0074b.getAbsolutePath());
                    sb.append("': length ");
                    sb.append(c0074b.length());
                    sb.append(" - crc: ");
                    sb.append(c0074b.f156d);
                    Log.i("MultiDex", sb.toString());
                    if (!z) {
                        c0074b.delete();
                        if (c0074b.exists()) {
                            Log.w("MultiDex", "Failed to delete corrupted secondary dex '" + c0074b.getPath() + "'");
                        }
                    }
                    z2 = z;
                    i2 = i3;
                }
                if (!z2) {
                    throw new IOException("Could not create zip file " + c0074b.getAbsolutePath() + " for secondary dex (" + i + ")");
                }
                i++;
                entry = zipFile.getEntry("classes" + i + ".dex");
            }
            try {
                zipFile.close();
            } catch (IOException e2) {
                Log.w("MultiDex", "Failed to close resource", e2);
            }
            return arrayList;
        } catch (Throwable th) {
            try {
                zipFile.close();
            } catch (IOException e3) {
                Log.w("MultiDex", "Failed to close resource", e3);
            }
            throw th;
        }
    }

    /* renamed from: k */
    private static void m2555k(Context context, String str, long j, long j2, List<C0074b> list) {
        SharedPreferences.Editor edit = m2562d(context).edit();
        edit.putLong(str + "timestamp", j);
        edit.putLong(str + "crc", j2);
        edit.putInt(str + "dex.number", list.size() + 1);
        int i = 2;
        for (C0074b c0074b : list) {
            edit.putLong(str + "dex.crc." + i, c0074b.f156d);
            edit.putLong(str + "dex.time." + i, c0074b.lastModified());
            i++;
        }
        edit.commit();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f155i.release();
        this.f154h.close();
        this.f153g.close();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: h */
    public List<? extends File> m2558h(Context context, String str, boolean z) {
        List<C0074b> list;
        Log.i("MultiDex", "MultiDexExtractor.load(" + this.f150d.getPath() + ", " + z + ", " + str + ")");
        if (this.f155i.isValid()) {
            if (!z && !m2559g(context, this.f150d, this.f151e, str)) {
                try {
                    list = m2557i(context, str);
                } catch (IOException e) {
                    Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", e);
                }
                Log.i("MultiDex", "load found " + list.size() + " secondary dex files");
                return list;
            }
            Log.i("MultiDex", z ? "Forced extraction must be performed." : "Detected that extraction must be performed.");
            List<C0074b> m2556j = m2556j();
            m2555k(context, str, m2561e(this.f150d), this.f151e, m2556j);
            list = m2556j;
            Log.i("MultiDex", "load found " + list.size() + " secondary dex files");
            return list;
        }
        throw new IllegalStateException("MultiDexExtractor was closed");
    }
}
