package androidx.multidex;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.zip.CRC32;
import java.util.zip.ZipException;

/* renamed from: androidx.multidex.c */
/* loaded from: classes.dex */
final class C0075c {

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: androidx.multidex.c$a */
    /* loaded from: classes.dex */
    public static class C0076a {

        /* renamed from: a */
        long f157a;

        /* renamed from: b */
        long f158b;

        C0076a() {
        }
    }

    /* renamed from: a */
    static long m2554a(RandomAccessFile randomAccessFile, C0076a c0076a) {
        CRC32 crc32 = new CRC32();
        long j = c0076a.f158b;
        randomAccessFile.seek(c0076a.f157a);
        int min = (int) Math.min(16384L, j);
        byte[] bArr = new byte[16384];
        while (true) {
            int read = randomAccessFile.read(bArr, 0, min);
            if (read == -1) {
                break;
            }
            crc32.update(bArr, 0, read);
            j -= read;
            if (j == 0) {
                break;
            }
            min = (int) Math.min(16384L, j);
        }
        return crc32.getValue();
    }

    /* renamed from: b */
    static C0076a m2553b(RandomAccessFile randomAccessFile) {
        long length = randomAccessFile.length() - 22;
        long j = 0;
        if (length < 0) {
            throw new ZipException("File too short to be a zip file: " + randomAccessFile.length());
        }
        long j2 = length - 65536;
        if (j2 >= 0) {
            j = j2;
        }
        int reverseBytes = Integer.reverseBytes(101010256);
        do {
            randomAccessFile.seek(length);
            if (randomAccessFile.readInt() == reverseBytes) {
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                randomAccessFile.skipBytes(2);
                C0076a c0076a = new C0076a();
                c0076a.f158b = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                c0076a.f157a = Integer.reverseBytes(randomAccessFile.readInt()) & 4294967295L;
                return c0076a;
            }
            length--;
        } while (length >= j);
        throw new ZipException("End Of Central Directory signature not found");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: c */
    public static long m2552c(File file) {
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        try {
            return m2554a(randomAccessFile, m2553b(randomAccessFile));
        } finally {
            randomAccessFile.close();
        }
    }
}
