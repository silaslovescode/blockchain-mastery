package androidx.multidex;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;

/* renamed from: androidx.multidex.a */
/* loaded from: classes.dex */
public final class C0064a {

    /* renamed from: a */
    private static final Set<File> f143a = new HashSet();

    /* renamed from: b */
    private static final boolean f144b = m2574m(System.getProperty("java.vm.version"));

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.multidex.a$a */
    /* loaded from: classes.dex */
    public static final class C0065a {

        /* renamed from: b */
        private static final int f145b = 4;

        /* renamed from: a */
        private final InterfaceC0066a f146a;

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: androidx.multidex.a$a$a */
        /* loaded from: classes.dex */
        public interface InterfaceC0066a {
            /* renamed from: a */
            Object mo2569a(File file, DexFile dexFile);
        }

        /* renamed from: androidx.multidex.a$a$b */
        /* loaded from: classes.dex */
        private static class C0067b implements InterfaceC0066a {

            /* renamed from: a */
            private final Constructor<?> f147a;

            C0067b(Class<?> cls) {
                Constructor<?> constructor = cls.getConstructor(File.class, ZipFile.class, DexFile.class);
                this.f147a = constructor;
                constructor.setAccessible(true);
            }

            @Override // androidx.multidex.C0064a.C0065a.InterfaceC0066a
            /* renamed from: a */
            public Object mo2569a(File file, DexFile dexFile) {
                return this.f147a.newInstance(file, new ZipFile(file), dexFile);
            }
        }

        /* renamed from: androidx.multidex.a$a$c */
        /* loaded from: classes.dex */
        private static class C0068c implements InterfaceC0066a {

            /* renamed from: a */
            private final Constructor<?> f148a;

            C0068c(Class<?> cls) {
                Constructor<?> constructor = cls.getConstructor(File.class, File.class, DexFile.class);
                this.f148a = constructor;
                constructor.setAccessible(true);
            }

            @Override // androidx.multidex.C0064a.C0065a.InterfaceC0066a
            /* renamed from: a */
            public Object mo2569a(File file, DexFile dexFile) {
                return this.f148a.newInstance(file, file, dexFile);
            }
        }

        /* renamed from: androidx.multidex.a$a$d */
        /* loaded from: classes.dex */
        private static class C0069d implements InterfaceC0066a {

            /* renamed from: a */
            private final Constructor<?> f149a;

            C0069d(Class<?> cls) {
                Constructor<?> constructor = cls.getConstructor(File.class, Boolean.TYPE, File.class, DexFile.class);
                this.f149a = constructor;
                constructor.setAccessible(true);
            }

            @Override // androidx.multidex.C0064a.C0065a.InterfaceC0066a
            /* renamed from: a */
            public Object mo2569a(File file, DexFile dexFile) {
                return this.f149a.newInstance(file, Boolean.FALSE, file, dexFile);
            }
        }

        private C0065a() {
            InterfaceC0066a c0069d;
            Class<?> cls = Class.forName("dalvik.system.DexPathList$Element");
            try {
                try {
                    c0069d = new C0067b(cls);
                } catch (NoSuchMethodException unused) {
                    c0069d = new C0068c(cls);
                }
            } catch (NoSuchMethodException unused2) {
                c0069d = new C0069d(cls);
            }
            this.f146a = c0069d;
        }

        /* renamed from: a */
        static void m2572a(ClassLoader classLoader, List<? extends File> list) {
            Object obj = C0064a.m2580g(classLoader, "pathList").get(classLoader);
            Object[] m2571b = new C0065a().m2571b(list);
            try {
                C0064a.m2581f(obj, "dexElements", m2571b);
            } catch (NoSuchFieldException e) {
                Log.w("MultiDex", "Failed find field 'dexElements' attempting 'pathElements'", e);
                C0064a.m2581f(obj, "pathElements", m2571b);
            }
        }

        /* renamed from: b */
        private Object[] m2571b(List<? extends File> list) {
            int size = list.size();
            Object[] objArr = new Object[size];
            for (int i = 0; i < size; i++) {
                File file = list.get(i);
                objArr[i] = this.f146a.mo2569a(file, DexFile.loadDex(file.getPath(), m2570c(file), 0));
            }
            return objArr;
        }

        /* renamed from: c */
        private static String m2570c(File file) {
            File parentFile = file.getParentFile();
            String name = file.getName();
            return new File(parentFile, name.substring(0, name.length() - f145b) + ".dex").getPath();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.multidex.a$b */
    /* loaded from: classes.dex */
    public static final class C0070b {
        /* renamed from: a */
        static void m2568a(ClassLoader classLoader, List<? extends File> list, File file) {
            IOException[] iOExceptionArr;
            Object obj = C0064a.m2580g(classLoader, "pathList").get(classLoader);
            ArrayList arrayList = new ArrayList();
            C0064a.m2581f(obj, "dexElements", m2567b(obj, new ArrayList(list), file, arrayList));
            if (arrayList.size() > 0) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    Log.w("MultiDex", "Exception in makeDexElement", (IOException) it.next());
                }
                Field m2580g = C0064a.m2580g(obj, "dexElementsSuppressedExceptions");
                IOException[] iOExceptionArr2 = (IOException[]) m2580g.get(obj);
                if (iOExceptionArr2 == null) {
                    iOExceptionArr = (IOException[]) arrayList.toArray(new IOException[arrayList.size()]);
                } else {
                    IOException[] iOExceptionArr3 = new IOException[arrayList.size() + iOExceptionArr2.length];
                    arrayList.toArray(iOExceptionArr3);
                    System.arraycopy(iOExceptionArr2, 0, iOExceptionArr3, arrayList.size(), iOExceptionArr2.length);
                    iOExceptionArr = iOExceptionArr3;
                }
                m2580g.set(obj, iOExceptionArr);
                IOException iOException = new IOException("I/O exception during makeDexElement");
                iOException.initCause((Throwable) arrayList.get(0));
                throw iOException;
            }
        }

        /* renamed from: b */
        private static Object[] m2567b(Object obj, ArrayList<File> arrayList, File file, ArrayList<IOException> arrayList2) {
            return (Object[]) C0064a.m2579h(obj, "makeDexElements", ArrayList.class, File.class, ArrayList.class).invoke(obj, arrayList, file, arrayList2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.multidex.a$c */
    /* loaded from: classes.dex */
    public static final class C0071c {
        /* renamed from: a */
        static void m2566a(ClassLoader classLoader, List<? extends File> list) {
            int size = list.size();
            Field m2580g = C0064a.m2580g(classLoader, "path");
            StringBuilder sb = new StringBuilder((String) m2580g.get(classLoader));
            String[] strArr = new String[size];
            File[] fileArr = new File[size];
            ZipFile[] zipFileArr = new ZipFile[size];
            DexFile[] dexFileArr = new DexFile[size];
            ListIterator<? extends File> listIterator = list.listIterator();
            while (listIterator.hasNext()) {
                File next = listIterator.next();
                String absolutePath = next.getAbsolutePath();
                sb.append(':');
                sb.append(absolutePath);
                int previousIndex = listIterator.previousIndex();
                strArr[previousIndex] = absolutePath;
                fileArr[previousIndex] = next;
                zipFileArr[previousIndex] = new ZipFile(next);
                dexFileArr[previousIndex] = DexFile.loadDex(absolutePath, absolutePath + ".dex", 0);
            }
            m2580g.set(classLoader, sb.toString());
            C0064a.m2581f(classLoader, "mPaths", strArr);
            C0064a.m2581f(classLoader, "mFiles", fileArr);
            C0064a.m2581f(classLoader, "mZips", zipFileArr);
            C0064a.m2581f(classLoader, "mDexs", dexFileArr);
        }
    }

    /* renamed from: d */
    private static void m2583d(Context context) {
        File file = new File(context.getFilesDir(), "secondary-dexes");
        if (file.isDirectory()) {
            Log.i("MultiDex", "Clearing old secondary dex dir (" + file.getPath() + ").");
            File[] listFiles = file.listFiles();
            if (listFiles == null) {
                Log.w("MultiDex", "Failed to list secondary dex dir content (" + file.getPath() + ").");
                return;
            }
            for (File file2 : listFiles) {
                Log.i("MultiDex", "Trying to delete old file " + file2.getPath() + " of size " + file2.length());
                if (!file2.delete()) {
                    Log.w("MultiDex", "Failed to delete old file " + file2.getPath());
                } else {
                    Log.i("MultiDex", "Deleted old file " + file2.getPath());
                }
            }
            if (!file.delete()) {
                Log.w("MultiDex", "Failed to delete secondary dex dir " + file.getPath());
                return;
            }
            Log.i("MultiDex", "Deleted old secondary dex dir " + file.getPath());
        }
    }

    /* renamed from: e */
    private static void m2582e(Context context, File file, File file2, String str, String str2, boolean z) {
        Set<File> set = f143a;
        synchronized (set) {
            if (set.contains(file)) {
                return;
            }
            set.add(file);
            int i = Build.VERSION.SDK_INT;
            if (i > 20) {
                Log.w("MultiDex", "MultiDex is not guaranteed to work in SDK version " + i + ": SDK version higher than 20 should be backed by runtime with built-in multidex capabilty but it's not the case here: java.vm.version=\"" + System.getProperty("java.vm.version") + "\"");
            }
            try {
                ClassLoader classLoader = context.getClassLoader();
                if (classLoader == null) {
                    Log.e("MultiDex", "Context class loader is null. Must be running in test mode. Skip patching.");
                    return;
                }
                m2583d(context);
                File m2577j = m2577j(context, file2, str);
                C0072b c0072b = new C0072b(file, m2577j);
                IOException e = null;
                try {
                    m2575l(classLoader, m2577j, c0072b.m2558h(context, str2, false));
                } catch (IOException e2) {
                    if (!z) {
                        throw e2;
                    }
                    Log.w("MultiDex", "Failed to install extracted secondary dex files, retrying with forced extraction", e2);
                    m2575l(classLoader, m2577j, c0072b.m2558h(context, str2, true));
                }
                try {
                    c0072b.close();
                } catch (IOException e3) {
                    e = e3;
                }
                if (e != null) {
                    throw e;
                }
            } catch (RuntimeException e4) {
                Log.w("MultiDex", "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", e4);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: f */
    public static void m2581f(Object obj, String str, Object[] objArr) {
        Field m2580g = m2580g(obj, str);
        Object[] objArr2 = (Object[]) m2580g.get(obj);
        Object[] objArr3 = (Object[]) Array.newInstance(objArr2.getClass().getComponentType(), objArr2.length + objArr.length);
        System.arraycopy(objArr2, 0, objArr3, 0, objArr2.length);
        System.arraycopy(objArr, 0, objArr3, objArr2.length, objArr.length);
        m2580g.set(obj, objArr3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: g */
    public static Field m2580g(Object obj, String str) {
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Field declaredField = cls.getDeclaredField(str);
                if (!declaredField.isAccessible()) {
                    declaredField.setAccessible(true);
                }
                return declaredField;
            } catch (NoSuchFieldException unused) {
            }
        }
        throw new NoSuchFieldException("Field " + str + " not found in " + obj.getClass());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: h */
    public static Method m2579h(Object obj, String str, Class<?>... clsArr) {
        for (Class<?> cls = obj.getClass(); cls != null; cls = cls.getSuperclass()) {
            try {
                Method declaredMethod = cls.getDeclaredMethod(str, clsArr);
                if (!declaredMethod.isAccessible()) {
                    declaredMethod.setAccessible(true);
                }
                return declaredMethod;
            } catch (NoSuchMethodException unused) {
            }
        }
        throw new NoSuchMethodException("Method " + str + " with parameters " + Arrays.asList(clsArr) + " not found in " + obj.getClass());
    }

    /* renamed from: i */
    private static ApplicationInfo m2578i(Context context) {
        try {
            return context.getApplicationInfo();
        } catch (RuntimeException e) {
            Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", e);
            return null;
        }
    }

    /* renamed from: j */
    private static File m2577j(Context context, File file, String str) {
        File file2 = new File(file, "code_cache");
        try {
            m2573n(file2);
        } catch (IOException unused) {
            file2 = new File(context.getFilesDir(), "code_cache");
            m2573n(file2);
        }
        File file3 = new File(file2, str);
        m2573n(file3);
        return file3;
    }

    /* renamed from: k */
    public static void m2576k(Context context) {
        String str;
        Log.i("MultiDex", "Installing application");
        if (f144b) {
            str = "VM has multidex support, MultiDex support library is disabled.";
        } else {
            int i = Build.VERSION.SDK_INT;
            if (i < 4) {
                throw new RuntimeException("MultiDex installation failed. SDK " + i + " is unsupported. Min SDK version is 4.");
            }
            try {
                ApplicationInfo m2578i = m2578i(context);
                if (m2578i == null) {
                    Log.i("MultiDex", "No ApplicationInfo available, i.e. running on a test Context: MultiDex support library is disabled.");
                    return;
                } else {
                    m2582e(context, new File(m2578i.sourceDir), new File(m2578i.dataDir), "secondary-dexes", "", true);
                    str = "install done";
                }
            } catch (Exception e) {
                Log.e("MultiDex", "MultiDex installation failure", e);
                throw new RuntimeException("MultiDex installation failed (" + e.getMessage() + ").");
            }
        }
        Log.i("MultiDex", str);
    }

    /* renamed from: l */
    private static void m2575l(ClassLoader classLoader, File file, List<? extends File> list) {
        if (!list.isEmpty()) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 19) {
                C0070b.m2568a(classLoader, list, file);
            } else if (i >= 14) {
                C0065a.m2572a(classLoader, list);
            } else {
                C0071c.m2566a(classLoader, list);
            }
        }
    }

    /* renamed from: m */
    static boolean m2574m(String str) {
        boolean z = false;
        if (str != null) {
            Matcher matcher = Pattern.compile("(\\d+)\\.(\\d+)(\\.\\d+)?").matcher(str);
            if (matcher.matches()) {
                try {
                    int parseInt = Integer.parseInt(matcher.group(1));
                    int parseInt2 = Integer.parseInt(matcher.group(2));
                    if (parseInt > 2 || (parseInt == 2 && parseInt2 >= 1)) {
                        z = true;
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("VM with version ");
        sb.append(str);
        sb.append(z ? " has multidex support" : " does not have multidex support");
        Log.i("MultiDex", sb.toString());
        return z;
    }

    /* renamed from: n */
    private static void m2573n(File file) {
        File parentFile;
        String str;
        file.mkdir();
        if (!file.isDirectory()) {
            if (file.getParentFile() == null) {
                str = "Failed to create dir " + file.getPath() + ". Parent file is null.";
            } else {
                str = "Failed to create dir " + file.getPath() + ". parent file is a dir " + parentFile.isDirectory() + ", a file " + parentFile.isFile() + ", exists " + parentFile.exists() + ", readable " + parentFile.canRead() + ", writable " + parentFile.canWrite();
            }
            Log.e("MultiDex", str);
            throw new IOException("Failed to create directory " + file.getPath());
        }
    }
}
