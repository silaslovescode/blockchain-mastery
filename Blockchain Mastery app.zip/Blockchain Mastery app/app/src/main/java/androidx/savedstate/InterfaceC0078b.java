package androidx.savedstate;

import androidx.lifecycle.InterfaceC0057g;

/* renamed from: androidx.savedstate.b */
/* loaded from: classes.dex */
public interface InterfaceC0078b extends InterfaceC0057g {
    /* renamed from: j */
    C0077a m2549j();
}
