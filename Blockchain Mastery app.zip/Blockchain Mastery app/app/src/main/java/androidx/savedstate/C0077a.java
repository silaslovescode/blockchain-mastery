package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;

@SuppressLint({"RestrictedApi"})
/* renamed from: androidx.savedstate.a */
/* loaded from: classes.dex */
public final class C0077a {

    /* renamed from: a */
    boolean f161a;

    /* renamed from: a */
    public Bundle m2550a(String str) {
        throw null;
    }
}
