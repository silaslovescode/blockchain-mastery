package androidx.core.app;

import android.app.Activity;
import androidx.lifecycle.InterfaceC0057g;

/* renamed from: androidx.core.app.b */
/* loaded from: classes.dex */
public class ActivityC0045b extends Activity implements InterfaceC0057g {
}
