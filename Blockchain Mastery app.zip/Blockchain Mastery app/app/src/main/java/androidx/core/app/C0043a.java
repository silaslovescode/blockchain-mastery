package androidx.core.app;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: androidx.core.app.a */
/* loaded from: classes.dex */
public final class C0043a {

    /* renamed from: androidx.core.app.a$a */
    /* loaded from: classes.dex */
    static class C0044a {

        /* renamed from: a */
        private static Method f89a;

        /* renamed from: b */
        private static boolean f90b;

        /* renamed from: a */
        public static IBinder m2630a(Bundle bundle, String str) {
            if (!f90b) {
                try {
                    Method method = Bundle.class.getMethod("getIBinder", String.class);
                    f89a = method;
                    method.setAccessible(true);
                } catch (NoSuchMethodException e) {
                    Log.i("BundleCompatBaseImpl", "Failed to retrieve getIBinder method", e);
                }
                f90b = true;
            }
            Method method2 = f89a;
            if (method2 != null) {
                try {
                    return (IBinder) method2.invoke(bundle, str);
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e2) {
                    Log.i("BundleCompatBaseImpl", "Failed to invoke getIBinder via reflection", e2);
                    f89a = null;
                }
            }
            return null;
        }
    }

    /* renamed from: a */
    public static IBinder m2631a(Bundle bundle, String str) {
        return Build.VERSION.SDK_INT >= 18 ? bundle.getBinder(str) : C0044a.m2630a(bundle, str);
    }
}
