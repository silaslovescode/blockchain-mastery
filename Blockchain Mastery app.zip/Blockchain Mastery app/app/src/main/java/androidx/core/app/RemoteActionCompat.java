package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.InterfaceC0082c;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements InterfaceC0082c {

    /* renamed from: a */
    public IconCompat f83a;

    /* renamed from: b */
    public CharSequence f84b;

    /* renamed from: c */
    public CharSequence f85c;

    /* renamed from: d */
    public PendingIntent f86d;

    /* renamed from: e */
    public boolean f87e;

    /* renamed from: f */
    public boolean f88f;
}
