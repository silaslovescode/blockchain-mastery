package androidx.window.layout;

import android.app.Activity;
import java.util.concurrent.Executor;
import p010e.p015c.p019c.InterfaceC2729a;

/* loaded from: classes.dex */
public interface WindowBackend {
    void registerLayoutChangeCallback(Activity activity, Executor executor, InterfaceC2729a<WindowLayoutInfo> interfaceC2729a);

    void unregisterLayoutChangeCallback(InterfaceC2729a<WindowLayoutInfo> interfaceC2729a);
}
