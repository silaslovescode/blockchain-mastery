package androidx.window.layout;

import android.graphics.Rect;

/* loaded from: classes.dex */
public interface DisplayFeature {
    Rect getBounds();
}
