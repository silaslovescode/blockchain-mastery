package androidx.window.layout;

import java.util.concurrent.Executor;

/* renamed from: androidx.window.layout.a */
/* loaded from: classes.dex */
public final /* synthetic */ class ExecutorC0094a implements Executor {

    /* renamed from: d */
    public static final /* synthetic */ ExecutorC0094a f183d = new ExecutorC0094a();

    private /* synthetic */ ExecutorC0094a() {
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
