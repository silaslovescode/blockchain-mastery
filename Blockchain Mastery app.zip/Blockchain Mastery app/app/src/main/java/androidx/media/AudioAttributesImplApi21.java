package androidx.media;

import android.annotation.TargetApi;
import android.media.AudioAttributes;

@TargetApi(21)
/* loaded from: classes.dex */
class AudioAttributesImplApi21 implements AudioAttributesImpl {

    /* renamed from: a */
    AudioAttributes f137a;

    /* renamed from: b */
    int f138b = -1;

    public boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesImplApi21)) {
            return false;
        }
        return this.f137a.equals(((AudioAttributesImplApi21) obj).f137a);
    }

    public int hashCode() {
        return this.f137a.hashCode();
    }

    public String toString() {
        return "AudioAttributesCompat: audioattributes=" + this.f137a;
    }
}
