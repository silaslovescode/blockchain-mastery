package androidx.media;

import androidx.versionedparcelable.InterfaceC0082c;

/* loaded from: classes.dex */
interface AudioAttributesImpl extends InterfaceC0082c {
}
