package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: androidx.lifecycle.d */
/* loaded from: classes.dex */
public abstract class AbstractC0052d {

    /* renamed from: androidx.lifecycle.d$a */
    /* loaded from: classes.dex */
    public enum EnumC0053a {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY
    }

    /* renamed from: androidx.lifecycle.d$b */
    /* loaded from: classes.dex */
    public enum EnumC0054b {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED;

        /* renamed from: a */
        public boolean m2609a(EnumC0054b enumC0054b) {
            return compareTo(enumC0054b) >= 0;
        }
    }

    public AbstractC0052d() {
        new AtomicReference();
    }

    /* renamed from: a */
    public abstract EnumC0054b mo2608a();

    /* renamed from: b */
    public abstract void mo2607b(InterfaceC0056f interfaceC0056f);
}
