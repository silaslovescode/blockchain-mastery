package androidx.lifecycle;

/* renamed from: androidx.lifecycle.b */
/* loaded from: classes.dex */
interface InterfaceC0050b extends InterfaceC0056f {
    /* renamed from: a */
    void m2616a(InterfaceC0057g interfaceC0057g);

    /* renamed from: b */
    void m2615b(InterfaceC0057g interfaceC0057g);

    /* renamed from: c */
    void m2614c(InterfaceC0057g interfaceC0057g);

    /* renamed from: e */
    void m2613e(InterfaceC0057g interfaceC0057g);

    /* renamed from: f */
    void m2612f(InterfaceC0057g interfaceC0057g);

    /* renamed from: g */
    void m2611g(InterfaceC0057g interfaceC0057g);
}
