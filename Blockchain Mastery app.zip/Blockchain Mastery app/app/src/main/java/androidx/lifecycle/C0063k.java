package androidx.lifecycle;

/* renamed from: androidx.lifecycle.k */
/* loaded from: classes.dex */
public class C0063k {
    /* renamed from: a */
    public final void m2593a() {
        throw null;
    }
}
