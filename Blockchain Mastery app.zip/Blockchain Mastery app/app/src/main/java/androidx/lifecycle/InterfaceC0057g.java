package androidx.lifecycle;

/* renamed from: androidx.lifecycle.g */
/* loaded from: classes.dex */
public interface InterfaceC0057g {
    /* renamed from: f */
    AbstractC0052d mo1414f();
}
