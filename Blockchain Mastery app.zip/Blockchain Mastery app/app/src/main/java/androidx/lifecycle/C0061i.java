package androidx.lifecycle;

import java.util.HashMap;

/* renamed from: androidx.lifecycle.i */
/* loaded from: classes.dex */
public class C0061i {
    public C0061i() {
        new HashMap();
    }
}
