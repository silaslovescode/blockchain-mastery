package androidx.lifecycle;

/* renamed from: androidx.lifecycle.f */
/* loaded from: classes.dex */
public interface InterfaceC0056f {
}
