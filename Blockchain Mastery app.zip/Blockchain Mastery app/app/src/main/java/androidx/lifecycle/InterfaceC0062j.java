package androidx.lifecycle;

/* renamed from: androidx.lifecycle.j */
/* loaded from: classes.dex */
public interface InterfaceC0062j<T> {
}
