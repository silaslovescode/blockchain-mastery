package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.c */
/* loaded from: classes.dex */
public interface InterfaceC0082c {
}
