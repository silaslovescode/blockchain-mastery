package androidx.versionedparcelable;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements InterfaceC0082c {
}
