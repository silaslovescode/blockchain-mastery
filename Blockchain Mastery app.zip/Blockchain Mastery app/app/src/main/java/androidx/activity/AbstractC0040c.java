package androidx.activity;

/* renamed from: androidx.activity.c */
/* loaded from: classes.dex */
public abstract class AbstractC0040c {
    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a */
    public abstract void m2635a(InterfaceC0038a interfaceC0038a);
}
