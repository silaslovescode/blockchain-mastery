package androidx.activity;

/* renamed from: androidx.activity.a */
/* loaded from: classes.dex */
interface InterfaceC0038a {
    void cancel();
}
