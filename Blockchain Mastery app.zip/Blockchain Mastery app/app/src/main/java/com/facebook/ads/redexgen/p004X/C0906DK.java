package com.facebook.ads.redexgen.p004X;

import java.util.UUID;

/* renamed from: com.facebook.ads.redexgen.X.DK */
/* loaded from: assets/audience_network.dex */
public class C0906DK {
    public final int A00;
    public final UUID A01;
    public final byte[] A02;

    public C0906DK(UUID uuid, int i, byte[] bArr) {
        this.A01 = uuid;
        this.A00 = i;
        this.A02 = bArr;
    }
}
