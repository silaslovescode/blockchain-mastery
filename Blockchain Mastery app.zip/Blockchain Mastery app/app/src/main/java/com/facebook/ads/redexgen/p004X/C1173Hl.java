package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Hl */
/* loaded from: assets/audience_network.dex */
public class C1173Hl extends IOException {
    public C1173Hl(IOException iOException) {
        super(iOException);
    }
}
