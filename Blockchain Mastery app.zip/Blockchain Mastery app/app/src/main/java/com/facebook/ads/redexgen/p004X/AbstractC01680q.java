package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.0q */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC01680q {
    public void A00() {
    }
}
