package com.facebook.ads.internal.view.dynamiclayout;

/* loaded from: assets/audience_network.dex */
public @interface DynamicWebViewController$AdFormatType {
}
