package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Ct */
/* loaded from: assets/audience_network.dex */
public final class C0881Ct {
    public final int A00;
    public final long A01;

    public C0881Ct(int i, long j) {
        this.A00 = i;
        this.A01 = j;
    }
}
