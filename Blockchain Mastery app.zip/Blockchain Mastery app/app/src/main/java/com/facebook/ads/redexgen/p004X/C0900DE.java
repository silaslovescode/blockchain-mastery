package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.DE */
/* loaded from: assets/audience_network.dex */
public final class C0900DE {
    public final int A00;
    public final long A01;

    public C0900DE(long j, int i) {
        this.A01 = j;
        this.A00 = i;
    }
}
