package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Kb */
/* loaded from: assets/audience_network.dex */
public final class C1345Kb extends C06929a {
}
