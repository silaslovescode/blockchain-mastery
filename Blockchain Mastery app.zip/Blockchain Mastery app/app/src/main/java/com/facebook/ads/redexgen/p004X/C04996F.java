package com.facebook.ads.redexgen.p004X;

import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.ads.redexgen.X.6F */
/* loaded from: assets/audience_network.dex */
public final class C04996F {
    public final List<InterfaceC04986E> A00 = new ArrayList();

    public final void A00(InterfaceC04986E interfaceC04986E) {
        this.A00.add(interfaceC04986E);
    }

    public final void A01(EnumC05426w enumC05426w) {
        for (InterfaceC04986E interfaceC04986E : this.A00) {
            interfaceC04986E.AFQ(enumC05426w);
        }
    }
}
