package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Dt */
/* loaded from: assets/audience_network.dex */
public final class C0941Dt {
    public final int A00;
    public final String A01;
    public final byte[] A02;

    public C0941Dt(String str, int i, byte[] bArr) {
        this.A01 = str;
        this.A00 = i;
        this.A02 = bArr;
    }
}
