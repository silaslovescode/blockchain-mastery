package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1x */
/* loaded from: assets/audience_network.dex */
public final class C02371x extends RuntimeException {
    public static final long serialVersionUID = 1;

    public C02371x(String str) {
        super(str);
    }
}
