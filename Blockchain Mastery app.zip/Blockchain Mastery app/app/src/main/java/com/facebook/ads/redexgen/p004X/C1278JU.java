package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.JU */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1278JU {
    public static final /* synthetic */ int[] A00 = new int[EnumC2537e3.values().length];

    static {
        try {
            A00[EnumC2537e3.A02.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC2537e3.A04.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC2537e3.A03.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
    }
}
