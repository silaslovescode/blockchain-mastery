package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Qo */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC1724Qo {
    public abstract void A02();

    public void A00() {
    }

    public void A01() {
    }
}
