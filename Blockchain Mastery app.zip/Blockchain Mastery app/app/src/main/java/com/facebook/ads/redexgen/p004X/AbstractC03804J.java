package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.4J */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC03804J {
    public void A00() {
    }
}
