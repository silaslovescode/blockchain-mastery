package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.Ax */
/* loaded from: assets/audience_network.dex */
public final class C0776Ax {
    public final long A00;
    public final long A01;
    public static final C0776Ax A04 = new C0776Ax(0, 0);
    public static final C0776Ax A02 = new C0776Ax(Long.MAX_VALUE, Long.MAX_VALUE);
    public static final C0776Ax A06 = new C0776Ax(Long.MAX_VALUE, 0);
    public static final C0776Ax A05 = new C0776Ax(0, Long.MAX_VALUE);
    public static final C0776Ax A03 = A04;

    public C0776Ax(long j, long j2) {
        boolean z = true;
        C1207IJ.A03(j >= 0);
        C1207IJ.A03(j2 < 0 ? false : z);
        this.A01 = j;
        this.A00 = j2;
    }

    public final boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C0776Ax c0776Ax = (C0776Ax) obj;
        return this.A01 == c0776Ax.A01 && this.A00 == c0776Ax.A00;
    }

    public final int hashCode() {
        return (((int) this.A01) * 31) + ((int) this.A00);
    }
}
