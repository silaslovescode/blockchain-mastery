package com.facebook.ads.redexgen.p004X;

import android.view.animation.Animation;

/* renamed from: com.facebook.ads.redexgen.X.MK  reason: invalid class name */
/* loaded from: assets/audience_network.dex */
public class animationAnimation$AnimationListenerC1448MK implements Animation.AnimationListener {
    @Override // android.view.animation.Animation.AnimationListener
    public void onAnimationEnd(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
    }
}
