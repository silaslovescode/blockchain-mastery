package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.7W */
/* loaded from: assets/audience_network.dex */
public class C05787W {
    public final String A00;
    public final String A01;
    public final String A02;
    public final String A03;
    public final String A04;

    public C05787W(String str, String str2, String str3, String str4, String str5) {
        this.A00 = str;
        this.A03 = str2;
        this.A02 = str3;
        this.A01 = str4;
        this.A04 = str5;
    }
}
