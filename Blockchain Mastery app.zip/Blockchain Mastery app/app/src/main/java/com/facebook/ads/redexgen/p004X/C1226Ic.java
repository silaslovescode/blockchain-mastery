package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Ic */
/* loaded from: assets/audience_network.dex */
public final class C1226Ic {
    public final int A00;
    public final int A01;
    public final boolean A02;

    public C1226Ic(int i, int i2, boolean z) {
        this.A00 = i;
        this.A01 = i2;
        this.A02 = z;
    }
}
