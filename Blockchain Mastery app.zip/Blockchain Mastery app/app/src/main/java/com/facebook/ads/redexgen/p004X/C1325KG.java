package com.facebook.ads.redexgen.p004X;

import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.facebook.ads.internal.protocol.AdErrorType;

/* renamed from: com.facebook.ads.redexgen.X.KG */
/* loaded from: assets/audience_network.dex */
public final class C1325KG {
    public final AdErrorType A00;
    public final String A01;

    public C1325KG(int i, String str) {
        this(AdErrorType.adErrorTypeFromCode(i), str);
    }

    public C1325KG(AdErrorType adErrorType, @Nullable String str) {
        str = TextUtils.isEmpty(str) ? adErrorType.getDefaultErrorMessage() : str;
        this.A00 = adErrorType;
        this.A01 = str;
    }

    public static C1325KG A00(AdErrorType adErrorType) {
        return new C1325KG(adErrorType, (String) null);
    }

    public static C1325KG A01(AdErrorType adErrorType, @Nullable String str) {
        return new C1325KG(adErrorType, str);
    }

    public static C1325KG A02(C1326KH c1326kh) {
        return new C1325KG(c1326kh.A00(), c1326kh.A01());
    }

    public final AdErrorType A03() {
        return this.A00;
    }

    public final String A04() {
        return this.A01;
    }
}
