package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.LB */
/* loaded from: assets/audience_network.dex */
public final class C1379LB extends Throwable {
    public C1379LB(String str) {
        super(str);
    }
}
