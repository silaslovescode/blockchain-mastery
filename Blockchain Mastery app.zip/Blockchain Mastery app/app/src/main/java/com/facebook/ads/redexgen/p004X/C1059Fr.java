package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Fr */
/* loaded from: assets/audience_network.dex */
public final class C1059Fr {
    public int A00;
    public long A01;
    public C0877Cn A02;
}
