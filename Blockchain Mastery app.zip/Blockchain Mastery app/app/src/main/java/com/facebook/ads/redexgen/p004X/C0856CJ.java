package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.CJ */
/* loaded from: assets/audience_network.dex */
public class C0856CJ extends Exception {
    public C0856CJ(Throwable th) {
        super(th);
    }
}
