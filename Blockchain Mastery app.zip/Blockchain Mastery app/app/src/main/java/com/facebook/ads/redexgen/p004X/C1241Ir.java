package com.facebook.ads.redexgen.p004X;

import java.util.Comparator;

/* renamed from: com.facebook.ads.redexgen.X.Ir */
/* loaded from: assets/audience_network.dex */
public class C1241Ir implements Comparator<C1242Is> {
    /* JADX INFO: Access modifiers changed from: private */
    @Override // java.util.Comparator
    /* renamed from: A00 */
    public final int compare(C1242Is c1242Is, C1242Is c1242Is2) {
        if (c1242Is.A00 < c1242Is2.A00) {
            return -1;
        }
        return c1242Is2.A00 < c1242Is.A00 ? 1 : 0;
    }
}
