package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.K8 */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1318K8 {
    public static final /* synthetic */ int[] A00 = new int[EnumC1319K9.valuesCustom().length];

    static {
        try {
            A00[EnumC1319K9.A03.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC1319K9.A05.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC1319K9.A04.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
    }
}
