package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.6j */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C05296j {
    public static final /* synthetic */ int[] A00 = new int[EnumC05396t.values().length];

    static {
        try {
            A00[EnumC05396t.A03.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC05396t.A04.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
