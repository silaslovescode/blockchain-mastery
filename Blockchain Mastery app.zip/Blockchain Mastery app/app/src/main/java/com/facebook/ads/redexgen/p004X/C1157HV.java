package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.HV */
/* loaded from: assets/audience_network.dex */
public final class C1157HV {
    public final int A00;
    public final byte[] A01;

    public C1157HV(byte[] bArr, int i) {
        this.A01 = bArr;
        this.A00 = i;
    }
}
