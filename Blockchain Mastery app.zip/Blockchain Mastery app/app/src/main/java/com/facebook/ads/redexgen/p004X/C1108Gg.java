package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gg */
/* loaded from: assets/audience_network.dex */
public final class C1108Gg {
    public int A00 = 0;
    public final int A01;
    public final int A02;
    public final byte[] A03;

    public C1108Gg(int i, int i2) {
        this.A02 = i;
        this.A01 = i2;
        this.A03 = new byte[(i2 * 2) - 1];
    }
}
