package com.facebook.ads.internal.view;

/* loaded from: assets/audience_network.dex */
public @interface ToolbarActionView$ToolbarActionMode {
}
