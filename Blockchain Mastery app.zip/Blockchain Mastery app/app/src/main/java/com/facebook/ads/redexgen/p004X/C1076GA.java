package com.facebook.ads.redexgen.p004X;

import java.util.UUID;

/* renamed from: com.facebook.ads.redexgen.X.GA */
/* loaded from: assets/audience_network.dex */
public class C1076GA extends AbstractC2514df<UUID> {
    public C1076GA(String str) {
        super(str);
    }
}
