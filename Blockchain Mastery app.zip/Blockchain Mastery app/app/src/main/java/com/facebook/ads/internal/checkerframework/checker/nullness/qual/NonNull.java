package com.facebook.ads.internal.checkerframework.checker.nullness.qual;

import com.facebook.ads.internal.checkerframework.framework.qual.DefaultFor;
import com.facebook.ads.internal.checkerframework.framework.qual.DefaultInUncheckedCodeFor;
import com.facebook.ads.internal.checkerframework.framework.qual.DefaultQualifierInHierarchy;
import com.facebook.ads.internal.checkerframework.framework.qual.QualifierForLiterals;
import com.facebook.ads.internal.checkerframework.framework.qual.SubtypeOf;
import com.facebook.ads.internal.checkerframework.framework.qual.UpperBoundFor;
import com.facebook.ads.redexgen.p004X.EnumC06108A;
import com.facebook.ads.redexgen.p004X.EnumC06208O;
import com.facebook.ads.redexgen.p004X.EnumC06218P;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@SubtypeOf({MonotonicNonNull.class})
@Target({ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@UpperBoundFor(typeKinds = {EnumC06208O.A0I, EnumC06208O.A0C, EnumC06208O.A04, EnumC06208O.A06, EnumC06208O.A08, EnumC06208O.A0B, EnumC06208O.A0E, EnumC06208O.A0J, EnumC06208O.A05})
@Retention(RetentionPolicy.RUNTIME)
@QualifierForLiterals({EnumC06108A.A0B})
@DefaultFor({EnumC06218P.A05})
@DefaultQualifierInHierarchy
@DefaultInUncheckedCodeFor({EnumC06218P.A0E, EnumC06218P.A0C})
@Documented
/* loaded from: assets/audience_network.dex */
public @interface NonNull {
}
