package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.H4 */
/* loaded from: assets/audience_network.dex */
public final class C1132H4 implements InterfaceC1767RV {
    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1767RV
    public final long A4e() {
        return System.nanoTime();
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1767RV
    public final void AEz(Object obj, long j) throws InterruptedException {
        obj.wait(j);
    }
}
