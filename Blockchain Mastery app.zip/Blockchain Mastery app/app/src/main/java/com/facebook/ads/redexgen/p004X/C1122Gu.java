package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gu */
/* loaded from: assets/audience_network.dex */
public final class C1122Gu {
    public final float A00;
    public final int A01;
    public final int A02;

    public C1122Gu(float f, int i, int i2) {
        this.A00 = f;
        this.A01 = i;
        this.A02 = i2;
    }
}
