package com.facebook.ads.internal.bench;

/* loaded from: classes.dex */
public class BenchmarkLimitsMs {
    public static final int GSF = 5;
    public static final int GSW = 1;

    private BenchmarkLimitsMs() {
    }
}
