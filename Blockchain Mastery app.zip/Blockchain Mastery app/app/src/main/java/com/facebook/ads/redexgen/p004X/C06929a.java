package com.facebook.ads.redexgen.p004X;

import java.io.Serializable;

/* renamed from: com.facebook.ads.redexgen.X.9a */
/* loaded from: assets/audience_network.dex */
public class C06929a implements Serializable {
}
