package com.facebook.ads.redexgen.p004X;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.os.Handler;
import androidx.annotation.NonNull;

@TargetApi(23)
/* renamed from: com.facebook.ads.redexgen.X.J9 */
/* loaded from: assets/audience_network.dex */
public final class C1257J9 implements MediaCodec.OnFrameRenderedListener {
    public final /* synthetic */ C02121Y A00;

    public C1257J9(C02121Y c02121y, MediaCodec mediaCodec) {
        this.A00 = c02121y;
        mediaCodec.setOnFrameRenderedListener(this, new Handler());
    }

    @Override // android.media.MediaCodec.OnFrameRenderedListener
    public final void onFrameRendered(@NonNull MediaCodec mediaCodec, long j, long j2) {
        if (this != this.A00.A00) {
            return;
        }
        this.A00.A1R();
    }
}
