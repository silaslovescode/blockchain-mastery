package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.Av */
/* loaded from: assets/audience_network.dex */
public final class C0774Av {
    public static final C0774Av A01 = new C0774Av(0);
    public final int A00;

    public C0774Av(int i) {
        this.A00 = i;
    }

    public final boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass() && this.A00 == ((C0774Av) obj).A00;
    }

    public final int hashCode() {
        return this.A00;
    }
}
