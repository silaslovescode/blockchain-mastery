package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.D2 */
/* loaded from: assets/audience_network.dex */
public final class C0888D2 extends C2096Ws {
    public long A00;

    public C0888D2() {
        super(1);
    }
}
