package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.6a */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C05206a {
    public static final /* synthetic */ int[] A00 = new int[EnumC05256f.values().length];

    static {
        try {
            A00[EnumC05256f.A0B.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
    }
}
