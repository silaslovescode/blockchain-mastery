package com.facebook.ads.redexgen.p004X;

import android.view.MotionEvent;
import android.view.View;

/* renamed from: com.facebook.ads.redexgen.X.Kd */
/* loaded from: assets/audience_network.dex */
public final class C1347Kd extends C06929a {
    public final MotionEvent A00;
    public final View A01;

    public C1347Kd(View view, MotionEvent motionEvent) {
        this.A01 = view;
        this.A00 = motionEvent;
    }

    public final MotionEvent A00() {
        return this.A00;
    }
}
