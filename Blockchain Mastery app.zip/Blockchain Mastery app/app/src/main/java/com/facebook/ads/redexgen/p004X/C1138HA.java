package com.facebook.ads.redexgen.p004X;

import androidx.annotation.NonNull;

/* renamed from: com.facebook.ads.redexgen.X.HA */
/* loaded from: assets/audience_network.dex */
public final class C1138HA implements Comparable<C1138HA> {
    public final int A00;
    public final C1134H6 A01;

    public C1138HA(int i, C1134H6 c1134h6) {
        this.A00 = i;
        this.A01 = c1134h6;
    }

    /* JADX INFO: Access modifiers changed from: private */
    @Override // java.lang.Comparable
    /* renamed from: A00 */
    public final int compareTo(@NonNull C1138HA c1138ha) {
        return this.A00 - c1138ha.A00;
    }
}
