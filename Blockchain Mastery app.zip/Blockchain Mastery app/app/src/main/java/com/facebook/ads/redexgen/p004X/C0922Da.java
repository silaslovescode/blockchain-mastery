package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Da */
/* loaded from: assets/audience_network.dex */
public final class C0922Da {
    public final int A00;
    public final C0924Dc A01;
    public final C0926De A02;
    public final byte[] A03;
    public final C0925Dd[] A04;

    public C0922Da(C0926De c0926De, C0924Dc c0924Dc, byte[] bArr, C0925Dd[] c0925DdArr, int i) {
        this.A02 = c0926De;
        this.A01 = c0924Dc;
        this.A03 = bArr;
        this.A04 = c0925DdArr;
        this.A00 = i;
    }
}
