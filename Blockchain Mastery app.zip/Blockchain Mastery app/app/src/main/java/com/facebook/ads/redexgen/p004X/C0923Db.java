package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Db */
/* loaded from: assets/audience_network.dex */
public final class C0923Db {
    public final int A00;
    public final int A01;
    public final int A02;
    public final boolean A03;
    public final long[] A04;

    public C0923Db(int i, int i2, long[] jArr, int i3, boolean z) {
        this.A00 = i;
        this.A01 = i2;
        this.A04 = jArr;
        this.A02 = i3;
        this.A03 = z;
    }
}
