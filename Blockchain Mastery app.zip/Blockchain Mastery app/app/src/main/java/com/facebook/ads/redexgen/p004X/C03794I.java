package com.facebook.ads.redexgen.p004X;

import android.database.Observable;

/* renamed from: com.facebook.ads.redexgen.X.4I */
/* loaded from: assets/audience_network.dex */
public class C03794I extends Observable<AbstractC03804J> {
    public final void A00() {
        for (int size = this.mObservers.size() - 1; size >= 0; size--) {
            ((AbstractC03804J) this.mObservers.get(size)).A00();
        }
    }
}
