package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import java.io.Closeable;
import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Lw */
/* loaded from: assets/audience_network.dex */
public final class C1424Lw implements Closeable {
    @Nullable
    public C1423Lv A00;
    public boolean A01;
    public final C1422Lu A02;
    public final Runnable A03;

    public C1424Lw(long j, Runnable runnable) {
        this.A02 = new C1422Lu(j);
        this.A02.A02();
        this.A03 = runnable;
        this.A01 = false;
    }

    private final synchronized void A03() {
        if (this.A00 == null && !this.A01) {
            this.A00 = new C1423Lv(this);
        }
    }

    public final C1422Lu A04() {
        return this.A02;
    }

    public final synchronized void A05() {
        if (this.A01) {
            return;
        }
        if (this.A00 == null) {
            this.A00 = new C1423Lv(this);
        }
        this.A00.A00();
    }

    public final synchronized void A06() {
        if (this.A02.A05() && !this.A01) {
            A03();
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        C1423Lv c1423Lv;
        synchronized (this) {
            this.A01 = true;
            c1423Lv = this.A00;
        }
        if (c1423Lv != null) {
            c1423Lv.close();
        }
    }
}
