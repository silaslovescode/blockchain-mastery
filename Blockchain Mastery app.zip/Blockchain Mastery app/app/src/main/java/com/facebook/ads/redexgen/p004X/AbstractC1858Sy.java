package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import java.util.Map;

/* renamed from: com.facebook.ads.redexgen.X.Sy */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC1858Sy implements InterfaceC1554O3 {
    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1554O3
    public void AAH(String str, Map<String, String> extraData) {
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1554O3
    public void AAl(int i, @Nullable String str) {
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1554O3
    public void AAw() {
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1554O3
    public void ABe() {
    }
}
