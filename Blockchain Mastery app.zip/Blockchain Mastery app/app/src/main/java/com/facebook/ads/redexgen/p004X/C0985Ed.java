package com.facebook.ads.redexgen.p004X;

import android.os.Parcel;

/* renamed from: com.facebook.ads.redexgen.X.Ed */
/* loaded from: assets/audience_network.dex */
public final class C0985Ed {
    public final int A00;
    public final long A01;

    public C0985Ed(int i, long j) {
        this.A00 = i;
        this.A01 = j;
    }

    public /* synthetic */ C0985Ed(int i, long j, C0984Ec c0984Ec) {
        this(i, j);
    }

    public static C0985Ed A00(Parcel parcel) {
        return new C0985Ed(parcel.readInt(), parcel.readLong());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A02(Parcel parcel) {
        parcel.writeInt(this.A00);
        parcel.writeLong(this.A01);
    }
}
