package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.IV */
/* loaded from: assets/audience_network.dex */
public final class C1219IV {
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final int A04;
    public final int A05;
    public final int A06;
    public final long A07;

    public C1219IV(byte[] bArr, int i) {
        C1231Ih c1231Ih = new C1231Ih(bArr);
        c1231Ih.A07(i * 8);
        this.A04 = c1231Ih.A04(16);
        this.A02 = c1231Ih.A04(16);
        this.A05 = c1231Ih.A04(24);
        this.A03 = c1231Ih.A04(24);
        this.A06 = c1231Ih.A04(20);
        this.A01 = c1231Ih.A04(3) + 1;
        this.A00 = c1231Ih.A04(5) + 1;
        this.A07 = ((c1231Ih.A04(4) & 15) << 32) | (c1231Ih.A04(32) & 4294967295L);
    }

    public final int A00() {
        return this.A00 * this.A06;
    }

    public final long A01() {
        return (this.A07 * 1000000) / this.A06;
    }
}
