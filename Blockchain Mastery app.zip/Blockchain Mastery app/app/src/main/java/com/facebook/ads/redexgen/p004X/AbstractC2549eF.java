package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import com.facebook.infer.annotation.Nullsafe;

@Nullsafe(Nullsafe.Mode.LOCAL)
/* renamed from: com.facebook.ads.redexgen.X.eF */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC2549eF {
    @Nullable
    public InterfaceC2548eE A00;

    public final void A00() {
        InterfaceC2548eE interfaceC2548eE = this.A00;
        if (interfaceC2548eE != null) {
            interfaceC2548eE.onStart();
        }
    }

    public final void A01() {
        InterfaceC2548eE interfaceC2548eE = this.A00;
        if (interfaceC2548eE != null) {
            interfaceC2548eE.onStop();
        }
    }

    public final void A02(InterfaceC2548eE interfaceC2548eE) {
        this.A00 = interfaceC2548eE;
    }
}
