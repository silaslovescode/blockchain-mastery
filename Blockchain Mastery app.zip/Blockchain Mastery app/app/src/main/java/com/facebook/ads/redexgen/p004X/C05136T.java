package com.facebook.ads.redexgen.p004X;

import java.util.ArrayList;
import java.util.List;

/* renamed from: com.facebook.ads.redexgen.X.6T */
/* loaded from: assets/audience_network.dex */
public final class C05136T {
    public final List<InterfaceC05236d> A00 = new ArrayList();

    public final void A00() {
        for (InterfaceC05236d biometricSignalLifecycleHandler : this.A00) {
            biometricSignalLifecycleHandler.AD3();
        }
    }

    public final void A01(InterfaceC05236d interfaceC05236d) {
        this.A00.add(interfaceC05236d);
    }
}
