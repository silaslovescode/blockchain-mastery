package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Id */
/* loaded from: assets/audience_network.dex */
public final class C1227Id {
    public final float A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final int A04;
    public final int A05;
    public final int A06;
    public final boolean A07;
    public final boolean A08;
    public final boolean A09;

    public C1227Id(int i, int i2, int i3, float f, boolean z, boolean z2, int i4, int i5, int i6, boolean z3) {
        this.A05 = i;
        this.A06 = i2;
        this.A02 = i3;
        this.A00 = f;
        this.A09 = z;
        this.A08 = z2;
        this.A01 = i4;
        this.A04 = i5;
        this.A03 = i6;
        this.A07 = z3;
    }
}
