package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.KO */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1332KO {
    public static final /* synthetic */ int[] A00 = new int[EnumC1333KP.values().length];

    static {
        try {
            A00[EnumC1333KP.A02.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
    }
}
