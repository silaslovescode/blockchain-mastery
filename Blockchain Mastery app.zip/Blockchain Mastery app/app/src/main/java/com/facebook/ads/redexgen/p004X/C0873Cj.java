package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Cj */
/* loaded from: assets/audience_network.dex */
public final class C0873Cj {
    public long A00;
}
