package com.facebook.ads.redexgen.p004X;

import android.util.SparseArray;

/* renamed from: com.facebook.ads.redexgen.X.Gm */
/* loaded from: assets/audience_network.dex */
public final class C1114Gm {
    public final int A00;
    public final int A01;
    public final int A02;
    public final SparseArray<C1115Gn> A03;

    public C1114Gm(int i, int i2, int i3, SparseArray<C1115Gn> sparseArray) {
        this.A01 = i;
        this.A02 = i2;
        this.A00 = i3;
        this.A03 = sparseArray;
    }
}
