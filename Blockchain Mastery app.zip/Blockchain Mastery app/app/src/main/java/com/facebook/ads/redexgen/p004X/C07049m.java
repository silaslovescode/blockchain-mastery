package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.9m */
/* loaded from: assets/audience_network.dex */
public final class C07049m {
    public final int A00;
    public final C07039l A01;

    public C07049m(int i, C07039l c07039l) {
        this.A00 = i;
        this.A01 = c07039l;
    }

    public final int A00() {
        return this.A00;
    }

    public final C07039l A01() {
        return this.A01;
    }
}
