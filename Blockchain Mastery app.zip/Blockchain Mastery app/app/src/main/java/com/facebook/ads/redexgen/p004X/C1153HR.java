package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import java.util.Arrays;

/* renamed from: com.facebook.ads.redexgen.X.HR */
/* loaded from: assets/audience_network.dex */
public final class C1153HR {
    public static String[] A03 = {"uPzvf3DrMkTy6OC2", "H2eIGrw6YlTuEfUMB", "p11InAYoC", "jGz94J", "ZtEJrdVWV1XC8XFg6mMZlCv5mMRi1ND1", "Ub1YY0rlTcSKb3yBclMaPE0dIwwpm8Yp", "Au1lLpT3HfOHruCfEBskEQ20fDVmu", "jui1pWNgNEO"};
    public int A00;
    public final int A01;
    public final InterfaceC1152HQ[] A02;

    public C1153HR(InterfaceC1152HQ... interfaceC1152HQArr) {
        this.A02 = interfaceC1152HQArr;
        this.A01 = interfaceC1152HQArr.length;
    }

    @Nullable
    public final InterfaceC1152HQ A00(int i) {
        return this.A02[i];
    }

    public final InterfaceC1152HQ[] A01() {
        return (InterfaceC1152HQ[]) this.A02.clone();
    }

    public final boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C1153HR c1153hr = (C1153HR) obj;
        String[] strArr = A03;
        if (strArr[1].length() == strArr[6].length()) {
            throw new RuntimeException();
        }
        String[] strArr2 = A03;
        strArr2[5] = "VymNKk7BYdZfYlSqFiIbjljOXHtGYALy";
        strArr2[4] = "eUsLwIc5zFGsQcnFIY6bSbYyt6aFMI1L";
        return Arrays.equals(this.A02, c1153hr.A02);
    }

    public final int hashCode() {
        if (this.A00 == 0) {
            this.A00 = (17 * 31) + Arrays.hashCode(this.A02);
        }
        int result = this.A00;
        return result;
    }
}
