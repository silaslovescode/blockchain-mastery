package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.I1 */
/* loaded from: assets/audience_network.dex */
public class C1189I1 extends IOException {
    public C1189I1(String str) {
        super(str);
    }

    public C1189I1(Throwable th) {
        super(th);
    }
}
