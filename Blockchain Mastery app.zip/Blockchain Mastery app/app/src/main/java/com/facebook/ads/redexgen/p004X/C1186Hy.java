package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Hy */
/* loaded from: assets/audience_network.dex */
public class C1186Hy extends IOException {
    public C1186Hy(IOException iOException) {
        super(iOException);
    }

    public C1186Hy(String str) {
        super(str);
    }
}
