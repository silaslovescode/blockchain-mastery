package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Af */
/* loaded from: assets/audience_network.dex */
public class C0758Af extends IOException {
    public C0758Af() {
    }

    public C0758Af(String str) {
        super(str);
    }

    public C0758Af(String str, Throwable th) {
        super(str, th);
    }
}
