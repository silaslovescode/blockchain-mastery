package com.facebook.ads.redexgen.p004X;

import androidx.annotation.RequiresApi;

@RequiresApi(22)
/* renamed from: com.facebook.ads.redexgen.X.0Z */
/* loaded from: assets/audience_network.dex */
public class C01520Z extends C01540b {
}
