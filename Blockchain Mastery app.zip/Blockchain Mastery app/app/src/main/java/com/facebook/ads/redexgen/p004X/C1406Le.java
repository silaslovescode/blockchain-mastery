package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Le */
/* loaded from: assets/audience_network.dex */
public final class C1406Le extends C06929a {
}
