package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Mz */
/* loaded from: assets/audience_network.dex */
public final class C1489Mz extends C06929a {
}
