package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.2A */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC02502A {
    public final double A00;
    public final double A01;
    public final double A02;
    public final boolean A03;

    public abstract void A00(boolean z, boolean z2, C02522C c02522c);

    public AbstractC02502A(double d, double d2, double d3, boolean z) {
        this.A01 = d;
        this.A00 = d2;
        this.A02 = d3;
        this.A03 = z;
    }
}
