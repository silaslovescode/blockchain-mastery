package com.facebook.ads.redexgen.p004X;

import android.content.Intent;
import java.util.ArrayList;

/* renamed from: com.facebook.ads.redexgen.X.2R */
/* loaded from: assets/audience_network.dex */
public final class C02672R {
    public final Intent A00;
    public final ArrayList<C02682S> A01;

    public C02672R(Intent intent, ArrayList<C02682S> arrayList) {
        this.A00 = intent;
        this.A01 = arrayList;
    }
}
