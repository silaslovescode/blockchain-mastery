package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.0J */
/* loaded from: assets/audience_network.dex */
public final class C01360J {
    public static <T> T A00(T reference) {
        if (reference != null) {
            return reference;
        }
        throw new NullPointerException();
    }
}
