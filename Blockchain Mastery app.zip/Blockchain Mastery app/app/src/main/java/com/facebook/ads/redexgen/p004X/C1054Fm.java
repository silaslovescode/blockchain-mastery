package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Fm */
/* loaded from: assets/audience_network.dex */
public final class C1054Fm {
    public final long A00;
    public final long A01;
    public final long A02;
    public final C1170Hi A03;

    public C1054Fm(C1170Hi c1170Hi, long j, long j2, long j3) {
        this.A03 = c1170Hi;
        this.A01 = j;
        this.A02 = j2;
        this.A00 = j3;
    }
}
