package com.facebook.ads.redexgen.p004X;

import android.content.res.Resources;
import android.util.DisplayMetrics;

/* renamed from: com.facebook.ads.redexgen.X.Lm */
/* loaded from: assets/audience_network.dex */
public final class C1414Lm {
    public static final DisplayMetrics A01 = Resources.getSystem().getDisplayMetrics();
    public static final float A00 = A01.density;
}
