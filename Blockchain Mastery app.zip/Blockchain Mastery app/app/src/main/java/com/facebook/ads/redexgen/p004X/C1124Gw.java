package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.Gw */
/* loaded from: assets/audience_network.dex */
public final class C1124Gw {
    public final float A00;
    public final float A01;
    public final float A02;
    public final float A03;
    public final int A04;
    public final int A05;
    public final int A06;
    @Nullable
    public final String A07;

    public C1124Gw(@Nullable String str) {
        this(str, Float.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE, Integer.MIN_VALUE, Float.MIN_VALUE);
    }

    public C1124Gw(@Nullable String str, float f, float f2, int i, int i2, float f3, int i3, float f4) {
        this.A07 = str;
        this.A01 = f;
        this.A00 = f2;
        this.A05 = i;
        this.A04 = i2;
        this.A03 = f3;
        this.A06 = i3;
        this.A02 = f4;
    }
}
