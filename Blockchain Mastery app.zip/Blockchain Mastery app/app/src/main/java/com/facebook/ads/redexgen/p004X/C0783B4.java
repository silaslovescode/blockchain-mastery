package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.B4 */
/* loaded from: assets/audience_network.dex */
public final class C0783B4 {
    public final int A00;
    public final C1040FY A01;

    public C0783B4(int i, C1040FY c1040fy) {
        this.A00 = i;
        this.A01 = c1040fy;
    }

    public final boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C0783B4 c0783b4 = (C0783B4) obj;
        return this.A00 == c0783b4.A00 && this.A01.equals(c0783b4.A01);
    }

    public final int hashCode() {
        return (this.A00 * 31) + this.A01.hashCode();
    }
}
