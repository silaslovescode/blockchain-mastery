package com.facebook.ads.redexgen.p004X;

import android.os.Build;
import android.widget.EdgeEffect;

/* renamed from: com.facebook.ads.redexgen.X.3i */
/* loaded from: assets/audience_network.dex */
public final class C03443i {
    public static final C03433h A00;

    static {
        if (Build.VERSION.SDK_INT >= 21) {
            A00 = new C2416c3();
        } else {
            A00 = new C03433h();
        }
    }

    public static void A00(EdgeEffect edgeEffect, float f, float f2) {
        A00.A00(edgeEffect, f, f2);
    }
}
