package com.facebook.ads.redexgen.p004X;

import java.io.Serializable;

/* renamed from: com.facebook.ads.redexgen.X.19 */
/* loaded from: assets/audience_network.dex */
public final class C018719 implements Serializable {
    public static final long serialVersionUID = 9136244113276723461L;
    public final C01981K A00;
    public final C01981K A01;

    public C018719(C01981K c01981k, C01981K c01981k2) {
        this.A01 = c01981k;
        this.A00 = c01981k2;
    }

    public final C01981K A00() {
        return this.A00;
    }

    public final C01981K A01() {
        return this.A01;
    }
}
