package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.73 */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C054973 {
    public static final /* synthetic */ int[] A00 = new int[EnumC055579.values().length];

    static {
        try {
            A00[EnumC055579.A06.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC055579.A0C.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC055579.A03.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
    }
}
