package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.GF */
/* loaded from: assets/audience_network.dex */
public final class C1081GF extends C2522dn {
    public C1081GF(String str, Throwable th) {
        super(str, th);
    }
}
