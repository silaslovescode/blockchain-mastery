package com.facebook.ads.redexgen.p004X;

import java.io.Serializable;

/* renamed from: com.facebook.ads.redexgen.X.1b */
/* loaded from: assets/audience_network.dex */
public final class C02151b implements Serializable {
    public static final long serialVersionUID = 42;
    public final String A00;
    public final String A01;

    public C02151b(C02141a c02141a) {
        String str;
        String str2;
        str = c02141a.A00;
        this.A00 = str;
        str2 = c02141a.A01;
        this.A01 = str2;
    }

    public final String A00() {
        return this.A00;
    }
}
