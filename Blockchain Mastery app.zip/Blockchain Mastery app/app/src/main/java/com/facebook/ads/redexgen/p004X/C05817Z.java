package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.7Z */
/* loaded from: assets/audience_network.dex */
public final class C05817Z {
    public int A00;
    public int A01;
    public boolean A02;

    public C05817Z(boolean z, int i, int i2) {
        this.A02 = z;
        this.A01 = i;
        this.A00 = i2;
    }

    public final int A00() {
        return this.A00;
    }

    public final int A01() {
        return this.A01;
    }

    public final boolean A02() {
        return this.A02;
    }
}
