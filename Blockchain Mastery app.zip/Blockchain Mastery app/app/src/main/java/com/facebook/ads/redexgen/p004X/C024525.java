package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.25 */
/* loaded from: assets/audience_network.dex */
public class C024525 {
    public final InterfaceC024727 A00;
    public final String A01;

    public C024525(String str, InterfaceC024727 interfaceC024727) {
        this.A01 = str;
        this.A00 = interfaceC024727;
    }
}
