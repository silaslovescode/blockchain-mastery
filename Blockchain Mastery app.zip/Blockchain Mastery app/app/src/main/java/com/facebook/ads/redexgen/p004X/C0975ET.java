package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.ET */
/* loaded from: assets/audience_network.dex */
public final class C0975ET {
    public final int A00;
    public final int A01;
    public final boolean A02;

    public C0975ET(int i, boolean z, int i2) {
        this.A01 = i;
        this.A02 = z;
        this.A00 = i2;
    }
}
