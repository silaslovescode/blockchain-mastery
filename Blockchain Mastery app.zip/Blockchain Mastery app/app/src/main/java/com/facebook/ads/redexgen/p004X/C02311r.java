package com.facebook.ads.redexgen.p004X;

import org.json.JSONObject;

/* renamed from: com.facebook.ads.redexgen.X.1r */
/* loaded from: assets/audience_network.dex */
public final class C02311r {
    public final long A00;
    public final C06759I A01;
    public final String A02;
    public final JSONObject A03;

    public C02311r(JSONObject jSONObject, C06759I c06759i, String str, long j) {
        this.A03 = jSONObject;
        this.A01 = c06759i;
        this.A02 = str;
        this.A00 = j;
    }

    public final long A00() {
        return this.A00;
    }

    public final C06759I A01() {
        return this.A01;
    }

    public final String A02() {
        return this.A02;
    }

    public final JSONObject A03() {
        return this.A03;
    }
}
