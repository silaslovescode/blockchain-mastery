package com.facebook.ads.redexgen.p004X;

import java.util.concurrent.ConcurrentLinkedQueue;

/* renamed from: com.facebook.ads.redexgen.X.Kv */
/* loaded from: assets/audience_network.dex */
public final class C1364Kv extends ConcurrentLinkedQueue<C1379LB> {
    public C1364Kv() {
    }

    public C1364Kv(C1364Kv c1364Kv) {
        super(c1364Kv);
    }
}
