package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Ko */
/* loaded from: assets/audience_network.dex */
public final class C1358Ko extends C06929a {
}
