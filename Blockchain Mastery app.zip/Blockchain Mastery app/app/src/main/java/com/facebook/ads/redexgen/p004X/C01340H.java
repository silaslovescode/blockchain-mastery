package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.0H */
/* loaded from: assets/audience_network.dex */
public class C01340H extends Exception {
    public C01340H(String str) {
        super(str);
    }

    public C01340H(String str, Throwable th) {
        super(str, th);
    }
}
