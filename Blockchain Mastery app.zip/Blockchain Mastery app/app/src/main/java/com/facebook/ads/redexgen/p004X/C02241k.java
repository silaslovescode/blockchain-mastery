package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1k */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C02241k {
    public static final /* synthetic */ int[] A00 = new int[EnumC02111X.values().length];

    static {
        try {
            A00[EnumC02111X.A04.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC02111X.A03.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
