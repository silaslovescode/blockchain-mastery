package com.facebook.ads.redexgen.p004X;

import com.facebook.ads.redexgen.p004X.C06929a;

/* renamed from: com.facebook.ads.redexgen.X.9c */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC06949c<T extends C06929a> {
    public abstract Class<T> A01();

    public abstract void A03(T t);

    /* JADX WARN: Generic types in debug info not equals: com.facebook.ads.redexgen.X.9c != com.facebook.ads.internal.events.EventSubscriber<T extends com.facebook.ads.redexgen.X.9a> */
    public final boolean A00(T t) {
        return true;
    }
}
