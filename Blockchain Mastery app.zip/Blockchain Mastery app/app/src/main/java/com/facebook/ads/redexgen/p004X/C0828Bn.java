package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Bn */
/* loaded from: assets/audience_network.dex */
public class C0828Bn extends C2096Ws {
    public long A00;

    public C0828Bn() {
        super(1);
    }
}
