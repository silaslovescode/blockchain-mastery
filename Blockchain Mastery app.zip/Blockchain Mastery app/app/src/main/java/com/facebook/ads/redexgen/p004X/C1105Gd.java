package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gd */
/* loaded from: assets/audience_network.dex */
public class C1105Gd {
    public int A00;
    public final int A01;
    public final boolean A02;

    public C1105Gd(int i, boolean z, int i2) {
        this.A01 = i;
        this.A02 = z;
        this.A00 = i2;
    }
}
