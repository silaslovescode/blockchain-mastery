package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.8u */
/* loaded from: assets/audience_network.dex */
public final class C06518u {
    public final int A00;
    public final C065790 A01;
    public final String A02;

    public C06518u(String str, int i, C065790 c065790) {
        this.A02 = str;
        this.A00 = i;
        this.A01 = c065790;
    }

    public final int A00() {
        return this.A00;
    }

    public final C065790 A01() {
        return this.A01;
    }

    public final String A02() {
        return this.A02;
    }
}
