package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.GC */
/* loaded from: assets/audience_network.dex */
public class C1078GC extends AbstractC2514df<Boolean> {
    public C1078GC(String str) {
        super(str);
    }
}
