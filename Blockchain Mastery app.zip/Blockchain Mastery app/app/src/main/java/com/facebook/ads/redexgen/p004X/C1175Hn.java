package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Hn */
/* loaded from: assets/audience_network.dex */
public class C1175Hn extends IOException {
    public final int A00;
    public final C1170Hi A01;

    public C1175Hn(IOException iOException, C1170Hi c1170Hi, int i) {
        super(iOException);
        this.A01 = c1170Hi;
        this.A00 = i;
    }

    public C1175Hn(String str, C1170Hi c1170Hi, int i) {
        super(str);
        this.A01 = c1170Hi;
        this.A00 = i;
    }

    public C1175Hn(String str, IOException iOException, C1170Hi c1170Hi, int i) {
        super(str, iOException);
        this.A01 = c1170Hi;
        this.A00 = i;
    }
}
