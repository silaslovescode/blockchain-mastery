package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.5q */
/* loaded from: assets/audience_network.dex */
public final class C04755q {
    public final long A00;
    public final EnumC04745p A01;
    public final String A02;
    public final boolean A03;

    public C04755q(String str, boolean z, EnumC04745p enumC04745p) {
        this(str, z, enumC04745p, System.currentTimeMillis());
    }

    public C04755q(String str, boolean z, EnumC04745p enumC04745p, long j) {
        this.A02 = str;
        this.A03 = z;
        this.A01 = enumC04745p;
        this.A00 = j;
    }

    public static C04755q A00() {
        return new C04755q("", true, EnumC04745p.A06, -1L);
    }

    public final long A01() {
        return this.A00;
    }

    public final EnumC04745p A02() {
        return this.A01;
    }

    public final String A03() {
        return this.A02;
    }

    public final boolean A04() {
        return this.A03;
    }
}
