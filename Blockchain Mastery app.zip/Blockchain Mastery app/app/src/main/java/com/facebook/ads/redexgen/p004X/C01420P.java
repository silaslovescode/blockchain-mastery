package com.facebook.ads.redexgen.p004X;

import androidx.annotation.RequiresApi;

@RequiresApi(23)
/* renamed from: com.facebook.ads.redexgen.X.0P */
/* loaded from: assets/audience_network.dex */
public class C01420P extends C01520Z {
}
