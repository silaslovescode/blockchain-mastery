package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.A0 */
/* loaded from: assets/audience_network.dex */
public class C0718A0 extends Exception {
    public C0718A0(String str) {
        super(str);
    }

    public C0718A0(String str, Throwable th) {
        super(str, th);
    }
}
