package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.86 */
/* loaded from: assets/audience_network.dex */
public final class C060786 extends AbstractC1497N8 {
    public int A00;

    public C060786(int i, int i2) {
        super(i);
        this.A00 = i2;
    }

    public final int A01() {
        return this.A00;
    }
}
