package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.6U */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C05146U {
    public static final /* synthetic */ int[] A00 = new int[EnumC05156V.values().length];

    static {
        try {
            A00[EnumC05156V.A0E.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC05156V.A03.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC05156V.A09.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            A00[EnumC05156V.A06.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            A00[EnumC05156V.A0A.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            A00[EnumC05156V.A0B.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            A00[EnumC05156V.A0D.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
        try {
            A00[EnumC05156V.A08.ordinal()] = 8;
        } catch (NoSuchFieldError unused8) {
        }
        try {
            A00[EnumC05156V.A05.ordinal()] = 9;
        } catch (NoSuchFieldError unused9) {
        }
        try {
            A00[EnumC05156V.A04.ordinal()] = 10;
        } catch (NoSuchFieldError unused10) {
        }
        try {
            A00[EnumC05156V.A0C.ordinal()] = 11;
        } catch (NoSuchFieldError unused11) {
        }
    }
}
