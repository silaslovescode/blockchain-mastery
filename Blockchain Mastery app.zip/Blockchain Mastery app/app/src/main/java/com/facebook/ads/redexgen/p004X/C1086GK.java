package com.facebook.ads.redexgen.p004X;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: com.facebook.ads.redexgen.X.GK */
/* loaded from: assets/audience_network.dex */
public class C1086GK implements InterfaceC2541e7 {
    public final List<InterfaceC2540e6> A00 = new ArrayList();

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC2541e7
    public final InterfaceC2540e6 A5X(int i) {
        return this.A00.get(i);
    }

    @Override // java.lang.Iterable
    public final Iterator<InterfaceC2540e6> iterator() {
        return this.A00.iterator();
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC2541e7
    public final int size() {
        return this.A00.size();
    }
}
