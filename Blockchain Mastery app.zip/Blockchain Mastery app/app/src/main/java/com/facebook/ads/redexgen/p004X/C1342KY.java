package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.KY */
/* loaded from: assets/audience_network.dex */
public final class C1342KY extends C06929a {
}
