package com.facebook.ads.redexgen.p004X;

import android.view.MotionEvent;

/* renamed from: com.facebook.ads.redexgen.X.2o */
/* loaded from: assets/audience_network.dex */
public final class C02892o {
    public static boolean A00(MotionEvent motionEvent, int i) {
        return (motionEvent.getSource() & i) == i;
    }
}
