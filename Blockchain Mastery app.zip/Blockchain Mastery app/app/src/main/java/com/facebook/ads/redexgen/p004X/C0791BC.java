package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.BC */
/* loaded from: assets/audience_network.dex */
public final class C0791BC {
    public int A00 = 0;
    public int A01 = 0;
    public int A02 = 1;

    public final C0792BD A00() {
        return new C0792BD(this.A00, this.A01, this.A02);
    }
}
