package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Is */
/* loaded from: assets/audience_network.dex */
public class C1242Is {
    public float A00;
    public int A01;
    public int A02;

    public C1242Is() {
    }

    public /* synthetic */ C1242Is(C1240Iq c1240Iq) {
        this();
    }
}
