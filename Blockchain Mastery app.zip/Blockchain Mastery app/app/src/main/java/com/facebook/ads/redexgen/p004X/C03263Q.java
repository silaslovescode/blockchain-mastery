package com.facebook.ads.redexgen.p004X;

import android.view.accessibility.AccessibilityEvent;

/* renamed from: com.facebook.ads.redexgen.X.3Q */
/* loaded from: assets/audience_network.dex */
public class C03263Q {
    public int A00(AccessibilityEvent accessibilityEvent) {
        return 0;
    }

    public void A01(AccessibilityEvent accessibilityEvent, int i) {
    }
}
