package com.facebook.ads.redexgen.p004X;

import androidx.annotation.RequiresApi;

@RequiresApi(17)
/* renamed from: com.facebook.ads.redexgen.X.FC */
/* loaded from: assets/audience_network.dex */
public class C1018FC extends C2420c7 {
}
