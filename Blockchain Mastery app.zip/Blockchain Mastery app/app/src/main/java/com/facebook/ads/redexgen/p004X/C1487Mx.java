package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Mx */
/* loaded from: assets/audience_network.dex */
public final class C1487Mx extends C06929a {
}
