package com.facebook.ads.redexgen.p004X;

import android.text.Layout;

/* renamed from: com.facebook.ads.redexgen.X.H7 */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1135H7 {
    public static final /* synthetic */ int[] A00 = new int[Layout.Alignment.values().length];

    static {
        try {
            A00[Layout.Alignment.ALIGN_NORMAL.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[Layout.Alignment.ALIGN_CENTER.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[Layout.Alignment.ALIGN_OPPOSITE.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
    }
}
