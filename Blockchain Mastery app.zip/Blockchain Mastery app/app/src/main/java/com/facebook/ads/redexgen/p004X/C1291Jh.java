package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Jh */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1291Jh {
    public static final /* synthetic */ int[] A00 = new int[EnumC1293Jj.values().length];

    static {
        try {
            A00[EnumC1293Jj.A0O.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC1293Jj.A0J.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC1293Jj.A07.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            A00[EnumC1293Jj.A0I.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            A00[EnumC1293Jj.A0P.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            A00[EnumC1293Jj.A0R.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            A00[EnumC1293Jj.A0S.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
    }
}
