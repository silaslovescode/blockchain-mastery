package com.facebook.ads.redexgen.p004X;

import java.util.Comparator;

/* renamed from: com.facebook.ads.redexgen.X.Iq */
/* loaded from: assets/audience_network.dex */
public class C1240Iq implements Comparator<C1242Is> {
    /* JADX INFO: Access modifiers changed from: private */
    @Override // java.util.Comparator
    /* renamed from: A00 */
    public final int compare(C1242Is c1242Is, C1242Is c1242Is2) {
        return c1242Is.A01 - c1242Is2.A01;
    }
}
