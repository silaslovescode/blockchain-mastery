package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Dd */
/* loaded from: assets/audience_network.dex */
public final class C0925Dd {
    public final int A00;
    public final int A01;
    public final int A02;
    public final boolean A03;

    public C0925Dd(boolean z, int i, int i2, int i3) {
        this.A03 = z;
        this.A02 = i;
        this.A01 = i2;
        this.A00 = i3;
    }
}
