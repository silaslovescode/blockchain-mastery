package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Ej */
/* loaded from: assets/audience_network.dex */
public final class C0989Ej extends IOException {
    public C0989Ej(String str) {
        super(str);
    }
}
