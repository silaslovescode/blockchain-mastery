package com.facebook.ads.redexgen.p004X;

import java.io.Serializable;

/* renamed from: com.facebook.ads.redexgen.X.1I */
/* loaded from: assets/audience_network.dex */
public final class C01961I implements Serializable {
    public static final long serialVersionUID = 5306126965868117466L;
    public final EnumC01941G A00;
    public final String A01;
    public final String A02;
    public final String A03;
    public final String A04;
    public final String A05;
    public final String A06;
    public final String A07;
    public final String A08;

    public C01961I(C01951H c01951h) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        EnumC01941G enumC01941G;
        str = c01951h.A08;
        this.A08 = str;
        str2 = c01951h.A07;
        this.A07 = str2;
        str3 = c01951h.A02;
        this.A02 = str3;
        str4 = c01951h.A05;
        this.A05 = str4;
        str5 = c01951h.A04;
        this.A04 = str5;
        str6 = c01951h.A01;
        this.A01 = str6;
        str7 = c01951h.A03;
        this.A03 = str7;
        str8 = c01951h.A06;
        this.A06 = str8;
        enumC01941G = c01951h.A00;
        this.A00 = enumC01941G;
    }

    public final EnumC01941G A00() {
        return this.A00;
    }

    public final String A01() {
        return this.A02;
    }

    public final String A02() {
        return this.A04;
    }

    public final String A03() {
        return this.A05;
    }

    public final String A04() {
        return this.A06;
    }

    public final String A05() {
        return this.A07;
    }

    public final String A06() {
        return this.A08;
    }
}
