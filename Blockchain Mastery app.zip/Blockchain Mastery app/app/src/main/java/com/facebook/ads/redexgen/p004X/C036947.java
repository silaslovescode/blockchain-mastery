package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.47 */
/* loaded from: assets/audience_network.dex */
public class C036947 {
    public int A00;
    public boolean A01;
    public boolean A02;
    public boolean A03;

    public final void A00() {
        this.A00 = 0;
        this.A01 = false;
        this.A03 = false;
        this.A02 = false;
    }
}
