package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.08 */
/* loaded from: assets/audience_network.dex */
public final class C012508 {
    public final int A00;
    public final int A01;
    public final boolean A02;
    public final boolean A03;
    public final boolean A04;

    public C012508(int i, boolean z, int i2, boolean z2, boolean z3) {
        this.A00 = i;
        this.A02 = z;
        this.A01 = i2;
        this.A03 = z2;
        this.A04 = z3;
    }

    public final int A00() {
        return this.A00;
    }

    public final int A01() {
        return this.A01;
    }

    public final boolean A02() {
        return this.A02;
    }

    public final boolean A03() {
        return this.A03;
    }

    public final boolean A04() {
        return this.A04;
    }
}
