package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.6P */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C05096P {
    public static final /* synthetic */ int[] A00 = new int[EnumC05106Q.values().length];

    static {
        try {
            A00[EnumC05106Q.A03.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
    }
}
