package com.facebook.ads.redexgen.p004X;

import android.view.Display;
import android.view.View;
import androidx.annotation.RequiresApi;

@RequiresApi(17)
/* renamed from: com.facebook.ads.redexgen.X.3W */
/* loaded from: assets/audience_network.dex */
public class C03323W extends C1021FF {
    @Override // com.facebook.ads.redexgen.p004X.C030837
    public final int A04(View view) {
        return view.getLayoutDirection();
    }

    @Override // com.facebook.ads.redexgen.p004X.C030837
    public final Display A07(View view) {
        return view.getDisplay();
    }
}
