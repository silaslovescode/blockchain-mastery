package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Lx */
/* loaded from: assets/audience_network.dex */
public final class C1425Lx {
    public final int A00;
    public final int A01;

    public C1425Lx(int i, int i2) {
        this.A01 = i;
        this.A00 = i2;
    }

    public final int A00() {
        return this.A00;
    }

    public final int A01() {
        return this.A01;
    }
}
