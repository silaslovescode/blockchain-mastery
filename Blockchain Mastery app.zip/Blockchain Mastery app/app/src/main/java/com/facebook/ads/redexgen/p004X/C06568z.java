package com.facebook.ads.redexgen.p004X;

import com.facebook.ads.AdError;

/* renamed from: com.facebook.ads.redexgen.X.8z */
/* loaded from: assets/audience_network.dex */
public final class C06568z {
    public static int A2N = 0;
    public static int A0P = AdError.NO_FILL_ERROR_CODE;
    public static int A0E = AdError.LOAD_TOO_FREQUENTLY_ERROR_CODE;
    public static int A0H = 1003;
    public static int A0I = 1004;
    public static int A0D = 1005;
    public static int A0K = 1006;
    public static int A0O = 1007;
    public static int A0T = 1008;
    public static int A0R = 1009;
    public static int A0W = 1010;
    public static int A0U = 1011;
    public static int A0N = 1012;
    public static int A0C = 1013;
    public static int A0V = 1014;
    public static int A0J = 1015;
    public static int A0L = 1016;
    public static int A0M = 1017;
    public static int A0Q = 1018;
    public static int A0G = 1019;
    public static int A0S = 1020;
    public static int A0F = 1021;
    public static int A1r = 1101;
    public static int A1m = 1102;
    public static int A1q = 1103;
    public static int A1o = 1104;
    public static int A1n = 1105;
    public static int A1p = 1111;
    public static int A0y = 1151;
    public static int A0z = 1152;
    public static int A10 = 1153;
    public static int A11 = 1154;
    public static int A0p = 1201;
    public static int A0o = 1202;
    public static int A0q = 1203;
    public static int A0n = 1204;
    public static int A0m = 1205;
    public static int A0r = 1206;
    public static int A29 = 1231;
    public static int A2B = 1232;
    public static int A2C = 1233;
    public static int A28 = 1234;
    public static int A2A = 1235;
    public static int A2E = 1236;
    public static int A2D = 1237;
    @Deprecated
    public static int A1R = 1301;
    @Deprecated
    public static int A1E = 1302;
    public static int A1F = 1303;
    public static int A1P = 1304;
    public static int A14 = 1306;
    public static int A1Q = 1307;
    public static int A1I = 1308;
    public static int A1G = 1309;
    public static int A19 = 1310;
    public static int A1A = 1311;
    public static int A1K = 1312;
    public static int A1L = 1313;
    public static int A1D = 1314;
    public static int A1M = 1315;
    public static int A1J = 1316;
    public static int A1C = 1317;
    public static int A1S = 1318;
    public static int A15 = 1319;
    public static int A1B = 1320;
    public static int A1N = 1321;
    public static int A1H = 1322;
    public static int A13 = 1323;
    public static int A1O = 1324;
    public static int A17 = 1325;
    public static int A16 = 1326;
    public static int A18 = 1327;
    public static int A2T = 1305;
    public static int A2Q = 2131;
    public static int A2F = 1401;
    public static int A2G = 1402;
    public static int A2H = 1501;
    public static int A2I = 1502;
    public static int A27 = 1601;
    public static int A26 = 1602;
    public static int A20 = 1701;
    public static int A1z = 1702;
    public static int A1s = 1703;
    public static int A1t = 1704;
    public static int A21 = 1705;
    public static int A1w = 1801;
    public static int A1x = 1802;
    public static int A1y = 1803;
    public static int A1u = 1804;
    public static int A1v = 1805;
    public static int A0X = 1901;
    public static int A0Y = 1902;
    public static int A1U = AdError.INTERNAL_ERROR_CODE;
    public static int A1W = AdError.CACHE_ERROR_CODE;
    public static int A1V = AdError.INTERNAL_ERROR_2003;
    public static int A1T = AdError.INTERNAL_ERROR_2004;
    public static int A0h = 2101;
    public static int A0i = 2102;
    public static int A0j = 2103;
    public static int A0b = 2104;
    public static int A0g = 2110;
    public static int A0k = 2111;
    public static int A0d = 2112;
    public static int A0c = 2113;
    public static int A0e = 2119;
    public static int A0a = 2120;
    public static int A0f = 2121;
    public static int A0l = 2130;
    @Deprecated
    public static int A07 = 2201;
    @Deprecated
    public static int A08 = 2202;
    public static int A01 = 2203;
    public static int A04 = 2204;
    public static int A02 = 2205;
    public static int A05 = 2206;
    public static int A09 = 2207;
    @Deprecated
    public static int A0A = 2208;
    @Deprecated
    public static int A03 = 2209;
    public static int A00 = 2010;
    public static int A06 = 2011;
    public static int A0B = 2012;
    @Deprecated
    public static int A1c = 2303;
    @Deprecated
    public static int A1Z = 2304;
    @Deprecated
    public static int A1X = 2305;
    @Deprecated
    public static int A1Y = 2306;
    @Deprecated
    public static int A1a = 2307;
    @Deprecated
    public static int A1b = 2308;
    public static int A1i = 2310;
    public static int A1e = 2311;
    public static int A1g = 2312;
    public static int A1h = 2313;
    public static int A1d = 2314;
    public static int A1f = 2315;
    public static int A2K = 2401;
    public static int A2M = 2402;
    public static int A2L = 2403;
    public static int A2J = 2404;
    public static int A0Z = 2501;
    public static int A2O = 2601;
    public static int A22 = 2651;
    public static int A23 = 2652;
    public static int A25 = 2653;
    public static int A24 = 2654;
    public static int A2R = 2701;
    public static int A2W = 2702;
    public static int A2Y = 2703;
    public static int A2V = 2704;
    public static int A2X = 2705;
    public static int A2S = 2706;
    public static int A2P = 2707;
    public static int A2U = 2708;
    public static int A1j = 2801;
    public static int A1l = 2901;
    public static int A1k = 2902;
    public static int A12 = AdError.MEDIATION_ERROR_CODE;
    public static int A0s = 3101;
    public static int A0w = 3102;
    public static int A0v = 3103;
    public static int A0x = 3104;
    public static int A0u = 3105;
    public static int A0t = 3106;
}
