package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.I8 */
/* loaded from: assets/audience_network.dex */
public class C1196I8 {
    public volatile long A00;
    public volatile long A01 = -1;
    public volatile long A02;

    public final long A00() {
        return this.A00 + this.A02;
    }
}
