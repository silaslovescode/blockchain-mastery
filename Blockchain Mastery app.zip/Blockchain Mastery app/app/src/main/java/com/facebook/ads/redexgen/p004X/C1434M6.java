package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.M6 */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1434M6 {
    public static final /* synthetic */ int[] A00 = new int[EnumC1435M7.values().length];

    static {
        try {
            A00[EnumC1435M7.A04.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
    }
}
