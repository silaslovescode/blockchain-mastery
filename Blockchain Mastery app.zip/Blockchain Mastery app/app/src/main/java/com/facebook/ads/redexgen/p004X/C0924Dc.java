package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Dc */
/* loaded from: assets/audience_network.dex */
public final class C0924Dc {
    public final int A00;
    public final String A01;
    public final String[] A02;

    public C0924Dc(String str, String[] strArr, int i) {
        this.A01 = str;
        this.A02 = strArr;
        this.A00 = i;
    }
}
