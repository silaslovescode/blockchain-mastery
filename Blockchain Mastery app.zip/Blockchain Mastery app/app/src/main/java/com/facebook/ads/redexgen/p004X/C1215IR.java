package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.IR */
/* loaded from: assets/audience_network.dex */
public final class C1215IR extends RuntimeException {
    public C1215IR(String str) {
        super(str);
    }
}
