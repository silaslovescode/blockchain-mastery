package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.DB */
/* loaded from: assets/audience_network.dex */
public final class C0897DB {
    public final int A00;
    public final long A01;
    public final int[] A02;
    public final int[] A03;
    public final long[] A04;
    public final long[] A05;

    public C0897DB(long[] jArr, int[] iArr, int i, long[] jArr2, int[] iArr2, long j) {
        this.A04 = jArr;
        this.A03 = iArr;
        this.A00 = i;
        this.A05 = jArr2;
        this.A02 = iArr2;
        this.A01 = j;
    }
}
