package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Ia */
/* loaded from: assets/audience_network.dex */
public final class C1224Ia {
    public final int A00;
    public final String A01;
    public final String A02;
}
