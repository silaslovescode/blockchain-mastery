package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Wr */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC2095Wr extends AbstractC0832Br {
    public int A00;
    public long A01;
}
