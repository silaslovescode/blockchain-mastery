package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.4W */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC03934W {
    public abstract boolean A0B(int i, int i2);
}
