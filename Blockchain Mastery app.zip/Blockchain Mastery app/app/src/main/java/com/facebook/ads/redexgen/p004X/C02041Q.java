package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1Q */
/* loaded from: assets/audience_network.dex */
public class C02041Q {
    public String A00;
    public String A01;
    public String A02;
    public String A03;

    public final C02041Q A04(String str) {
        this.A00 = str;
        return this;
    }

    public final C02041Q A05(String str) {
        this.A01 = str;
        return this;
    }

    public final C02041Q A06(String str) {
        this.A02 = str;
        return this;
    }

    public final C02041Q A07(String str) {
        this.A03 = str;
        return this;
    }

    public final C02051R A08() {
        return new C02051R(this);
    }
}
