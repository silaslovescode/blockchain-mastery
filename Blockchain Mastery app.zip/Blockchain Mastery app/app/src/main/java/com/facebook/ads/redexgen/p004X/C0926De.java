package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.De */
/* loaded from: assets/audience_network.dex */
public final class C0926De {
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final int A04;
    public final int A05;
    public final long A06;
    public final long A07;
    public final boolean A08;
    public final byte[] A09;

    public C0926De(long j, int i, long j2, int i2, int i3, int i4, int i5, int i6, boolean z, byte[] bArr) {
        this.A07 = j;
        this.A05 = i;
        this.A06 = j2;
        this.A00 = i2;
        this.A02 = i3;
        this.A01 = i4;
        this.A03 = i5;
        this.A04 = i6;
        this.A08 = z;
        this.A09 = bArr;
    }
}
