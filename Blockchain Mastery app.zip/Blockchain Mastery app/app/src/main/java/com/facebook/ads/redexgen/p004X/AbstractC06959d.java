package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.9d */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC06959d<T> {
    /* JADX WARN: Generic types in debug info not equals: com.facebook.ads.redexgen.X.9d != com.facebook.ads.internal.eventstorage.AdEventStorageCallback<T> */
    public void A01(int i, String str) {
    }

    /* JADX WARN: Generic types in debug info not equals: com.facebook.ads.redexgen.X.9d != com.facebook.ads.internal.eventstorage.AdEventStorageCallback<T> */
    public void A02(T result) {
    }
}
