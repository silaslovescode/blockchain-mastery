package com.facebook.ads.redexgen.p004X;

import android.os.SystemClock;
import com.facebook.infer.annotation.Nullsafe;

@Nullsafe(Nullsafe.Mode.LOCAL)
/* renamed from: com.facebook.ads.redexgen.X.GL */
/* loaded from: assets/audience_network.dex */
public final class C1087GL implements InterfaceC1801S3 {
    @Override // com.facebook.ads.redexgen.p004X.InterfaceC1801S3
    public final long A9h() {
        return SystemClock.elapsedRealtime();
    }
}
