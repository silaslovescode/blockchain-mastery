package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.KD */
/* loaded from: assets/audience_network.dex */
public class C1323KD {
    public final int A00;
    public final int A01;
    public final int A02;

    public C1323KD(int i, int i2, int i3) {
        this.A02 = i;
        this.A00 = i2;
        this.A01 = i3;
    }

    public /* synthetic */ C1323KD(int i, int i2, int i3, RunnableC1321KB runnableC1321KB) {
        this(i, i2, i3);
    }
}
