package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.9v */
/* loaded from: assets/audience_network.dex */
public class C07139v {
    public final int A00;
    public final int A01;
    public final C07019j A02;

    public C07139v(C07019j c07019j, int i, int i2) {
        this.A02 = c07019j;
        this.A01 = i;
        this.A00 = i2;
    }
}
