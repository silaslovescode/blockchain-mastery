package com.facebook.ads.redexgen.p004X;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;

/* renamed from: com.facebook.ads.redexgen.X.97 */
/* loaded from: assets/audience_network.dex */
public class C066497 implements SensorEventListener {
    public C066497() {
    }

    @Override // android.hardware.SensorEventListener
    public final void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.hardware.SensorEventListener
    public final void onSensorChanged(SensorEvent sensorEvent) {
        C066598.A0E(sensorEvent.values);
        C066598.A05();
    }
}
