package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gn */
/* loaded from: assets/audience_network.dex */
public final class C1115Gn {
    public final int A00;
    public final int A01;

    public C1115Gn(int i, int i2) {
        this.A00 = i;
        this.A01 = i2;
    }
}
