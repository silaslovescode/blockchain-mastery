package com.facebook.ads.redexgen.p004X;

import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.RequiresApi;

@RequiresApi(18)
/* renamed from: com.facebook.ads.redexgen.X.3S */
/* loaded from: assets/audience_network.dex */
public class C03283S extends C1018FC {
    @Override // com.facebook.ads.redexgen.p004X.C03293T
    public final String A02(AccessibilityNodeInfo accessibilityNodeInfo) {
        return accessibilityNodeInfo.getViewIdResourceName();
    }
}
