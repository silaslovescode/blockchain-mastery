package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.3E */
/* loaded from: assets/audience_network.dex */
public class C03143E {
    public float A00;
    public float A01;
    public int A02;
    public Object A03;
    public boolean A04;
}
