package com.facebook.ads.redexgen.p004X;

import android.os.Handler;

/* renamed from: com.facebook.ads.redexgen.X.C8 */
/* loaded from: assets/audience_network.dex */
public final class C0848C8 {
    public final Handler A00;
    public final InterfaceC0850CA A01;

    public C0848C8(Handler handler, InterfaceC0850CA interfaceC0850CA) {
        this.A00 = handler;
        this.A01 = interfaceC0850CA;
    }
}
