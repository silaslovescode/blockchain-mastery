package com.facebook.ads.redexgen.p004X;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.facebook.ads.redexgen.X.LE */
/* loaded from: assets/audience_network.dex */
public final class C1382LE {
    public static String[] A00 = {"XnOcKNlJJ8CDQQR", "VGhv6FkZrITxQRu9gbMUemqcetkh7B5f", "vVz2BTpV32jHfI", "d8hV", "Sy49NQqrKXgvTEWwSBtXX6HecYQBIBGU", "Db46iG0BOxvexN4G9aNEWNZ9mU0XJx13", "mKukGrwwCcIhJco4KmzrvmgYUSCtT5hL", "T8hiTRn5Amgadg81lccjSSIUWb1StHzV"};
    public static final AtomicReference<InterfaceC1381LD> A01 = new AtomicReference<>(null);

    public static InterfaceC1381LD A00() {
        InterfaceC1381LD interfaceC1381LD = A01.get();
        if (A00[5].charAt(26) != '0') {
            throw new RuntimeException();
        }
        String[] strArr = A00;
        strArr[7] = "JAkiPTeS8Sgp4wJmZ2cE1Xuhf0WoAHfE";
        strArr[4] = "TWyum6rZOmg61QmMcVNeRxvFtffIUfDC";
        if (interfaceC1381LD == null) {
            InterfaceC1381LD errorLogger = new C1907Tm();
            return errorLogger;
        }
        return interfaceC1381LD;
    }

    public static void A01(InterfaceC1381LD interfaceC1381LD) {
        A01.set(interfaceC1381LD);
    }
}
