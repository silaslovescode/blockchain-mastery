package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Hf */
/* loaded from: assets/audience_network.dex */
public final class C1167Hf extends IOException {
    public final int A00;

    public C1167Hf(int i) {
        this.A00 = i;
    }
}
