package com.facebook.ads.internal.checkerframework.framework.qual;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX WARN: Method from annotation default annotation not found: stringPatterns */
/* JADX WARN: Method from annotation default annotation not found: value */
@Target({ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
/* loaded from: assets/audience_network.dex */
public @interface QualifierForLiterals {
}
