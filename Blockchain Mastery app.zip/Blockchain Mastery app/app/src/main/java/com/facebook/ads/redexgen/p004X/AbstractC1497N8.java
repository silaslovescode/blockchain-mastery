package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.N8 */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC1497N8 extends C06929a {
    public int A00;

    public AbstractC1497N8(int i) {
        this.A00 = i;
    }

    public final int A00() {
        return this.A00;
    }
}
