package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.G1 */
/* loaded from: assets/audience_network.dex */
public class C1069G1 extends AbstractC2514df<String> {
    public C1069G1(String str) {
        super(str);
    }
}
