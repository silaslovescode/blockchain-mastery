package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Xk */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC2150Xk<T> extends AbstractC06378g<T> {
}
