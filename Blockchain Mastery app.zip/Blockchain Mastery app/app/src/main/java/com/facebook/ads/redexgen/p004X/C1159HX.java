package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.HX */
/* loaded from: assets/audience_network.dex */
public final class C1159HX extends IOException {
    public C1159HX(IOException iOException) {
        super(iOException);
    }
}
