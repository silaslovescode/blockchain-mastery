package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1H */
/* loaded from: assets/audience_network.dex */
public class C01951H {
    public EnumC01941G A00;
    public String A01;
    public String A02;
    public String A03;
    public String A04;
    public String A05;
    public String A06;
    public String A07;
    public String A08;

    public final C01951H A09(String str) {
        this.A00 = EnumC01941G.A00(str);
        return this;
    }

    public final C01951H A0A(String str) {
        this.A01 = str;
        return this;
    }

    public final C01951H A0B(String str) {
        this.A02 = str;
        return this;
    }

    public final C01951H A0C(String str) {
        this.A03 = str;
        return this;
    }

    public final C01951H A0D(String str) {
        this.A04 = str;
        return this;
    }

    public final C01951H A0E(String str) {
        this.A05 = str;
        return this;
    }

    public final C01951H A0F(String str) {
        this.A06 = str;
        return this;
    }

    public final C01951H A0G(String str) {
        this.A07 = str;
        return this;
    }

    public final C01951H A0H(String str) {
        this.A08 = str;
        return this;
    }

    public final C01961I A0I() {
        return new C01961I(this);
    }
}
