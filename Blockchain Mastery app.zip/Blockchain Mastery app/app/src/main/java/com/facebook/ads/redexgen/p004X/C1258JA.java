package com.facebook.ads.redexgen.p004X;

import android.annotation.TargetApi;
import android.hardware.display.DisplayManager;

@TargetApi(17)
/* renamed from: com.facebook.ads.redexgen.X.JA */
/* loaded from: assets/audience_network.dex */
public final class C1258JA implements DisplayManager.DisplayListener {
    public final DisplayManager A00;
    public final /* synthetic */ C1260JC A01;

    public C1258JA(C1260JC c1260jc, DisplayManager displayManager) {
        this.A01 = c1260jc;
        this.A00 = displayManager;
    }

    public final void A00() {
        this.A00.registerDisplayListener(this, null);
    }

    public final void A01() {
        this.A00.unregisterDisplayListener(this);
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayAdded(int i) {
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayChanged(int i) {
        if (i != 0) {
            return;
        }
        this.A01.A03();
    }

    @Override // android.hardware.display.DisplayManager.DisplayListener
    public final void onDisplayRemoved(int i) {
    }
}
