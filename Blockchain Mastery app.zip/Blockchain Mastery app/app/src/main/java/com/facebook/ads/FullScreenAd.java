package com.facebook.ads;

import androidx.annotation.Keep;
import com.facebook.ads.InterfaceC0099Ad;

/* loaded from: classes.dex */
public interface FullScreenAd extends InterfaceC0099Ad {

    @Keep
    /* loaded from: classes.dex */
    public interface ShowAdConfig {
    }

    @Keep
    /* loaded from: classes.dex */
    public interface ShowConfigBuilder {
        /* renamed from: build */
        ShowAdConfig mo2798build();
    }

    /* renamed from: buildLoadAdConfig */
    InterfaceC0099Ad.LoadConfigBuilder mo2794buildLoadAdConfig();

    /* renamed from: buildShowAdConfig */
    ShowConfigBuilder mo2795buildShowAdConfig();

    boolean show();
}
