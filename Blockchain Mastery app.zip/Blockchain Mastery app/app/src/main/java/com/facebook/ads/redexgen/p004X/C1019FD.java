package com.facebook.ads.redexgen.p004X;

import android.view.accessibility.AccessibilityEvent;
import androidx.annotation.RequiresApi;

@RequiresApi(19)
/* renamed from: com.facebook.ads.redexgen.X.FD */
/* loaded from: assets/audience_network.dex */
public class C1019FD extends C2421c8 {
    @Override // com.facebook.ads.redexgen.p004X.C03263Q
    public final int A00(AccessibilityEvent accessibilityEvent) {
        return accessibilityEvent.getContentChangeTypes();
    }

    @Override // com.facebook.ads.redexgen.p004X.C03263Q
    public final void A01(AccessibilityEvent accessibilityEvent, int i) {
        accessibilityEvent.setContentChangeTypes(i);
    }
}
