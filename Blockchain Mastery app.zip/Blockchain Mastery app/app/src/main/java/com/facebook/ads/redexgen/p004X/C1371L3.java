package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.L3 */
/* loaded from: assets/audience_network.dex */
public final class C1371L3 extends C06929a {
}
