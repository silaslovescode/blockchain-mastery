package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.GZ */
/* loaded from: assets/audience_network.dex */
public final class C1101GZ extends Exception {
    public C1101GZ(String str) {
        super(str);
    }

    public C1101GZ(String str, Throwable th) {
        super(str, th);
    }
}
