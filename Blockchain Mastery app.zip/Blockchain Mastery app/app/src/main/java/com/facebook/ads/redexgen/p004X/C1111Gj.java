package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gj */
/* loaded from: assets/audience_network.dex */
public final class C1111Gj {
    public final int A00;
    public final int[] A01;
    public final int[] A02;
    public final int[] A03;

    public C1111Gj(int i, int[] iArr, int[] iArr2, int[] iArr3) {
        this.A00 = i;
        this.A01 = iArr;
        this.A02 = iArr2;
        this.A03 = iArr3;
    }
}
