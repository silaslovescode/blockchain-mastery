package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Dl */
/* loaded from: assets/audience_network.dex */
public final class C0933Dl {
    public static String[] A0G = {"Ap6BNJVrmScnFk1hMNs3gk3nfiOqRLL3", "ykUqwa9hjGiITCeS7mR9oTL7PlhG", "aa4WgtRMvf8T1H", "JRczJFV5HPZSgdF19FYO330C4qz", "DshyegtLBVWJb272GUnrCLDL902Y6CT4", "mdvT8We7lZzQ3otG", "HTCQc9aRCuJwCScXqz5EEwOn0qroPb", "au3IbZji4KTf1MJXqcScv4"};
    public int A00;
    public int A01;
    public int A02;
    public int A03;
    public int A04;
    public int A05;
    public int A06;
    public int A07;
    public int A08;
    public C1227Id A09;
    public boolean A0A;
    public boolean A0B;
    public boolean A0C;
    public boolean A0D;
    public boolean A0E;
    public boolean A0F;

    public C0933Dl() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0055, code lost:
        if (r4 != false) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0059, code lost:
        if (r6.A0B == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x005f, code lost:
        if (r5.A0A != r6.A0A) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0061, code lost:
        r1 = r5.A05;
        r0 = r6.A05;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0065, code lost:
        if (r1 == r0) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0067, code lost:
        if (r1 == 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0069, code lost:
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x006f, code lost:
        if (r5.A09.A04 != 0) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0071, code lost:
        r4 = r6.A09.A04;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0082, code lost:
        if (com.facebook.ads.redexgen.p004X.C0933Dl.A0G[0].charAt(30) == 'd') goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0084, code lost:
        r2 = com.facebook.ads.redexgen.p004X.C0933Dl.A0G;
        r2[7] = "5biFR31Ww6IVJRQpoWySMi";
        r2[3] = "JIZ9t5zNUO5N5gZGQiecPim8SVz";
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0090, code lost:
        if (r4 != 0) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0092, code lost:
        r4 = r5.A06;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x009f, code lost:
        if (com.facebook.ads.redexgen.p004X.C0933Dl.A0G[5].length() == 16) goto L45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00a3, code lost:
        if (r4 != r6.A06) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00a9, code lost:
        if (r5.A02 != r6.A02) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00af, code lost:
        if (r5.A09.A04 != 1) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00b5, code lost:
        if (r6.A09.A04 != 1) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00bb, code lost:
        if (r5.A00 != r6.A00) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00c1, code lost:
        if (r5.A01 != r6.A01) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00c3, code lost:
        r1 = r5.A0E;
        r0 = r6.A0E;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00c7, code lost:
        if (r1 != r0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00c9, code lost:
        if (r1 == false) goto L73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00cb, code lost:
        if (r0 == false) goto L73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00d1, code lost:
        if (r5.A04 == r6.A04) goto L73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00d4, code lost:
        com.facebook.ads.redexgen.p004X.C0933Dl.A0G[5] = "2WzXkDzYE8eWwBtW";
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00dd, code lost:
        if (r4 != r6.A06) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00e0, code lost:
        if (r4 != 0) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00ef, code lost:
        if (r4 != false) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:?, code lost:
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:?, code lost:
        return true;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean A00(com.facebook.ads.redexgen.p004X.C0933Dl r6) {
        /*
            Method dump skipped, instructions count: 245
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.ads.redexgen.p004X.C0933Dl.A00(com.facebook.ads.redexgen.X.Dl):boolean");
    }

    public final void A02() {
        this.A0D = false;
        this.A0F = false;
    }

    public final void A03(int i) {
        this.A08 = i;
        this.A0D = true;
    }

    public final void A04(C1227Id c1227Id, int i, int i2, int i3, int i4, boolean z, boolean z2, boolean z3, boolean z4, int i5, int i6, int i7, int i8, int i9) {
        this.A09 = c1227Id;
        this.A05 = i;
        this.A08 = i2;
        this.A03 = i3;
        this.A07 = i4;
        this.A0C = z;
        this.A0B = z2;
        this.A0A = z3;
        this.A0E = z4;
        this.A04 = i5;
        this.A06 = i6;
        this.A02 = i7;
        this.A00 = i8;
        this.A01 = i9;
        this.A0F = true;
        this.A0D = true;
    }

    public final boolean A05() {
        int i;
        return this.A0D && ((i = this.A08) == 7 || i == 2);
    }
}
