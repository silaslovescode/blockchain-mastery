package com.facebook.ads.redexgen.p004X;

import android.net.Uri;
import androidx.annotation.Nullable;
import java.util.Arrays;

/* renamed from: com.facebook.ads.redexgen.X.IE */
/* loaded from: assets/audience_network.dex */
public final class C1202IE {
    public static byte[] A00;

    static {
        A03();
    }

    public static String A02(int i, int i2, int i3) {
        byte[] copyOfRange = Arrays.copyOfRange(A00, i, i + i2);
        for (int i4 = 0; i4 < copyOfRange.length; i4++) {
            copyOfRange[i4] = (byte) ((copyOfRange[i4] - i3) - 88);
        }
        return new String(copyOfRange);
    }

    public static void A03() {
        A00 = new byte[]{-40, -21, -30, -46, -33, -40, -31, -10, 9, 0, -16, 3, -10, -11, -6, 3};
    }

    public static long A00(InterfaceC1201ID interfaceC1201ID) {
        return interfaceC1201ID.A5W(A02(0, 7, 27), -1L);
    }

    @Nullable
    public static Uri A01(InterfaceC1201ID interfaceC1201ID) {
        String A5Y = interfaceC1201ID.A5Y(A02(7, 9, 57), null);
        if (A5Y == null) {
            return null;
        }
        return Uri.parse(A5Y);
    }

    public static void A04(C1203IF c1203if) {
        c1203if.A01(A02(7, 9, 57));
    }

    public static void A05(C1203IF c1203if, long j) {
        c1203if.A02(A02(0, 7, 27), j);
    }

    public static void A06(C1203IF c1203if, Uri uri) {
        c1203if.A03(A02(7, 9, 57), uri.toString());
    }
}
