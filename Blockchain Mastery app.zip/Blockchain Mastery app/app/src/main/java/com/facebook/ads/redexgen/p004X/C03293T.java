package com.facebook.ads.redexgen.p004X;

import android.view.accessibility.AccessibilityNodeInfo;

/* renamed from: com.facebook.ads.redexgen.X.3T */
/* loaded from: assets/audience_network.dex */
public class C03293T {
    public Object A00(int i, int i2, int i3, int i4, boolean z, boolean z2) {
        return null;
    }

    public Object A01(int i, int i2, boolean z, int i3) {
        return null;
    }

    public String A02(AccessibilityNodeInfo accessibilityNodeInfo) {
        return null;
    }

    public void A03(AccessibilityNodeInfo accessibilityNodeInfo, Object obj) {
    }

    public void A04(AccessibilityNodeInfo accessibilityNodeInfo, Object obj) {
    }
}
