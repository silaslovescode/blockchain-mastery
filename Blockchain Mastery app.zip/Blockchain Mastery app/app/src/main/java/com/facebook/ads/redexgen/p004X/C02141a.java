package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1a */
/* loaded from: assets/audience_network.dex */
public class C02141a {
    public String A00;
    public String A01;

    public final C02141a A02(String str) {
        this.A00 = str;
        return this;
    }

    public final C02141a A03(String str) {
        this.A01 = str;
        return this;
    }

    public final C02151b A04() {
        return new C02151b(this);
    }
}
