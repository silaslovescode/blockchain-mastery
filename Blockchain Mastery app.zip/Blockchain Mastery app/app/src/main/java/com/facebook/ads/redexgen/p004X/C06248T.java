package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.facebook.ads.redexgen.X.8T */
/* loaded from: assets/audience_network.dex */
public final class C06248T {
    public static final AtomicReference<C2153Xn> A00 = new AtomicReference<>();

    @Nullable
    public static C2153Xn A00() {
        return A00.get();
    }

    public static void A01(C2153Xn c2153Xn) {
        if (c2153Xn == null) {
            return;
        }
        A00.compareAndSet(null, c2153Xn);
    }
}
