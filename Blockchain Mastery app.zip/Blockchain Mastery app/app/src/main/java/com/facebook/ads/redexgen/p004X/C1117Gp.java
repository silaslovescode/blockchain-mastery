package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gp */
/* loaded from: assets/audience_network.dex */
public final class C1117Gp {
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;
    public final int A04;
    public final int A05;

    public C1117Gp(int i, int i2, int i3, int i4, int i5, int i6) {
        this.A04 = i;
        this.A03 = i2;
        this.A02 = i3;
        this.A05 = i4;
        this.A01 = i5;
        this.A00 = i6;
    }
}
