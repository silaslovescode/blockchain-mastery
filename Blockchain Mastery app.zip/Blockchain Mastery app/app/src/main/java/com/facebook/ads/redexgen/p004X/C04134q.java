package com.facebook.ads.redexgen.p004X;

import android.view.View;

/* renamed from: com.facebook.ads.redexgen.X.4q */
/* loaded from: assets/audience_network.dex */
public final class C04134q {
    public C04104n A00 = new C04104n();
    public final InterfaceC04114o A01;

    public C04134q(InterfaceC04114o interfaceC04114o) {
        this.A01 = interfaceC04114o;
    }

    public final View A00(int end, int next, int i, int i2) {
        int childStart = this.A01.A77();
        int A76 = this.A01.A76();
        int i3 = next > end ? 1 : -1;
        View view = null;
        while (end != next) {
            View A5y = this.A01.A5y(end);
            this.A00.A03(childStart, A76, this.A01.A61(A5y), this.A01.A60(A5y));
            if (i != 0) {
                this.A00.A01();
                this.A00.A02(i);
                if (this.A00.A04()) {
                    return A5y;
                }
            }
            if (i2 != 0) {
                this.A00.A01();
                this.A00.A02(i2);
                if (this.A00.A04()) {
                    view = A5y;
                }
            }
            end += i3;
        }
        return view;
    }
}
