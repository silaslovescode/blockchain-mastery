package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.5t */
/* loaded from: assets/audience_network.dex */
public class C04785t {
    @Nullable
    public String A00;
    @Nullable
    public String A01;
    public boolean A02;

    public C04785t(@Nullable String str, @Nullable String str2, boolean z) {
        this.A01 = str;
        this.A00 = str2;
        this.A02 = z;
    }
}
