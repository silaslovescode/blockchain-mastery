package com.facebook.ads.redexgen.p004X;

import java.util.UUID;

/* renamed from: com.facebook.ads.redexgen.X.9P */
/* loaded from: assets/audience_network.dex */
public final class C06819P {
    public final double A01 = System.currentTimeMillis() / 1000.0d;
    public final String A02 = UUID.randomUUID().toString();
    public final double A00 = Math.random();

    public final double A00() {
        return this.A00;
    }

    public final double A01() {
        return this.A01;
    }

    public final String A02() {
        return this.A02;
    }
}
