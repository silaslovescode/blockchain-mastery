package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

@VisibleForTesting
/* renamed from: com.facebook.ads.redexgen.X.8g */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC06378g<T> {
    public EnumC06368f A00;

    @Nullable
    public abstract T A03();

    /* JADX WARN: Generic types in debug info not equals: com.facebook.ads.redexgen.X.8g != com.facebook.ads.internal.database.AdDatabaseQuery<T> */
    public final EnumC06368f A00() {
        return this.A00;
    }

    /* JADX WARN: Generic types in debug info not equals: com.facebook.ads.redexgen.X.8g != com.facebook.ads.internal.database.AdDatabaseQuery<T> */
    public final void A01(EnumC06368f enumC06368f) {
        this.A00 = enumC06368f;
    }
}
