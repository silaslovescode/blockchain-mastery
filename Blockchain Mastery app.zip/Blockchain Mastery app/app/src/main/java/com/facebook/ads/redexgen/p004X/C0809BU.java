package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.BU */
/* loaded from: assets/audience_network.dex */
public final class C0809BU extends Exception {
    public C0809BU(String str) {
        super(str);
    }

    public C0809BU(Throwable th) {
        super(th);
    }
}
