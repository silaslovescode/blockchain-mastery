package com.facebook.ads.redexgen.p004X;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;

/* renamed from: com.facebook.ads.redexgen.X.96 */
/* loaded from: assets/audience_network.dex */
public class C066396 implements SensorEventListener {
    public C066396() {
    }

    @Override // android.hardware.SensorEventListener
    public final void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.hardware.SensorEventListener
    public final void onSensorChanged(SensorEvent sensorEvent) {
        C066598.A0D(sensorEvent.values);
        C066598.A04();
    }
}
