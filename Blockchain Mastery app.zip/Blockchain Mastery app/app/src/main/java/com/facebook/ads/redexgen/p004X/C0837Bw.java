package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Bw */
/* loaded from: assets/audience_network.dex */
public final class C0837Bw {
    public int A00;
    public int A01;
    public int A02;
    public int A03;
    public int A04;
    public int A05;
    public int A06;
    public int A07;
    public int A08;

    public final synchronized void A00() {
    }
}
