package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.AM */
/* loaded from: assets/audience_network.dex */
public final class C0740AM extends Exception {
    public final int A00;
    public final int A01;

    public C0740AM(int i, String str, Throwable th, int i2) {
        super(str, th);
        this.A01 = i;
        this.A00 = i2;
    }

    public static C0740AM A00(IOException iOException) {
        return new C0740AM(0, null, iOException, -1);
    }

    public static C0740AM A01(Exception exc, int i) {
        return new C0740AM(1, null, exc, i);
    }

    public static C0740AM A02(RuntimeException runtimeException) {
        return new C0740AM(2, null, runtimeException, -1);
    }
}
