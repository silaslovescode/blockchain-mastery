package com.facebook.ads.internal.shield;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
/* loaded from: assets/audience_network.dex */
public @interface NoAutoExceptionHandling {
}
