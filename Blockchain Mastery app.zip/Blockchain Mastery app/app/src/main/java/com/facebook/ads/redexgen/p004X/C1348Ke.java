package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Ke */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1348Ke {
    public static final /* synthetic */ int[] A00 = new int[EnumC1329KL.values().length];

    static {
        try {
            A00[EnumC1329KL.A0D.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC1329KL.A0E.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC1329KL.A0F.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            A00[EnumC1329KL.A0C.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
    }
}
