package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.J8 */
/* loaded from: assets/audience_network.dex */
public final class C1256J8 {
    public final int A00;
    public final int A01;
    public final int A02;

    public C1256J8(int i, int i2, int i3) {
        this.A02 = i;
        this.A00 = i2;
        this.A01 = i3;
    }
}
