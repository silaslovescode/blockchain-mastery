package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.75 */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C055175 {
    public static final /* synthetic */ int[] A00 = new int[EnumC055276.values().length];

    static {
        try {
            A00[EnumC055276.A08.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
    }
}
