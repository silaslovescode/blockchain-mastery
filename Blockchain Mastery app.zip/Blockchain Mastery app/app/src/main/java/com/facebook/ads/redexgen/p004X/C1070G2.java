package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.G2 */
/* loaded from: assets/audience_network.dex */
public class C1070G2 extends AbstractC2514df<Long> {
    public C1070G2(String str) {
        super(str);
    }
}
