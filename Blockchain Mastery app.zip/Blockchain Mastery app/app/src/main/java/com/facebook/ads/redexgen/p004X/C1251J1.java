package com.facebook.ads.redexgen.p004X;

import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.ads.internal.exoplayer2.video.ColorInfo;

/* renamed from: com.facebook.ads.redexgen.X.J1 */
/* loaded from: assets/audience_network.dex */
public class C1251J1 implements Parcelable.Creator<ColorInfo> {
    /* JADX INFO: Access modifiers changed from: private */
    @Override // android.os.Parcelable.Creator
    /* renamed from: A00 */
    public final ColorInfo createFromParcel(Parcel parcel) {
        return new ColorInfo(parcel);
    }

    /* JADX INFO: Access modifiers changed from: private */
    @Override // android.os.Parcelable.Creator
    /* renamed from: A01 */
    public final ColorInfo[] newArray(int i) {
        return new ColorInfo[0];
    }
}
