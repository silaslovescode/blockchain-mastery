package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.D9 */
/* loaded from: assets/audience_network.dex */
public final class C0895D9 {
    public final int A00;
    public final int A01;
    public final int A02;
    public final int A03;

    public C0895D9(int i, int i2, int i3, int i4) {
        this.A02 = i;
        this.A00 = i2;
        this.A03 = i3;
        this.A01 = i4;
    }
}
