package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.9l */
/* loaded from: assets/audience_network.dex */
public final class C07039l {
    public final int A00;
    public final int A01;
    public final int A02;
    public final EnumC07029k A03;

    public C07039l(EnumC07029k enumC07029k, int i, int i2, int i3) {
        this.A03 = enumC07029k;
        this.A01 = i;
        this.A00 = i2;
        this.A02 = i3;
    }

    public final int A00() {
        return this.A00;
    }

    public final int A01() {
        return this.A01;
    }

    public final int A02() {
        return this.A02;
    }

    public final EnumC07029k A03() {
        return this.A03;
    }
}
