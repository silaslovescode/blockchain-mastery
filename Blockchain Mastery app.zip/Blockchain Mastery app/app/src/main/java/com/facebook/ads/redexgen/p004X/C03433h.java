package com.facebook.ads.redexgen.p004X;

import android.widget.EdgeEffect;

/* renamed from: com.facebook.ads.redexgen.X.3h */
/* loaded from: assets/audience_network.dex */
public class C03433h {
    public void A00(EdgeEffect edgeEffect, float f, float f2) {
        edgeEffect.onPull(f);
    }
}
