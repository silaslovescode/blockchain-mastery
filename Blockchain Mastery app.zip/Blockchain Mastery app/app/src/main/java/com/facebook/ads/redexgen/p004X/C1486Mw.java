package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Mw */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1486Mw {
    public static final /* synthetic */ int[] A00 = new int[EnumC1657Pj.values().length];

    static {
        try {
            A00[EnumC1657Pj.A04.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC1657Pj.A03.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
