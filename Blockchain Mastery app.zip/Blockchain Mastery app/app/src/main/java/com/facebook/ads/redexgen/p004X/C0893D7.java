package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.D7 */
/* loaded from: assets/audience_network.dex */
public final class C0893D7 {
    public final int A00;
    public final int A01;
    public final long A02;

    public C0893D7(int i, long j, int i2) {
        this.A00 = i;
        this.A02 = j;
        this.A01 = i2;
    }
}
