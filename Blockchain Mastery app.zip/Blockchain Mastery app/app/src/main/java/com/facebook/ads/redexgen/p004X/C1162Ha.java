package com.facebook.ads.redexgen.p004X;

import java.io.IOException;

/* renamed from: com.facebook.ads.redexgen.X.Ha */
/* loaded from: assets/audience_network.dex */
public class C1162Ha extends IOException {
    public C1162Ha(IOException iOException) {
        super(iOException);
    }
}
