package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Kw */
/* loaded from: assets/audience_network.dex */
public final class C1365Kw extends C06929a {
    public final int A00;
    public final int A01;

    public C1365Kw(int i, int i2) {
        this.A00 = i;
        this.A01 = i2;
    }

    public final int A00() {
        return this.A00;
    }

    public final int A01() {
        return this.A01;
    }
}
