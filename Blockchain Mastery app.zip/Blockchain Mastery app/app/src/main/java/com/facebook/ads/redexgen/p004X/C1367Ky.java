package com.facebook.ads.redexgen.p004X;

import android.os.Handler;
import android.os.Looper;

/* renamed from: com.facebook.ads.redexgen.X.Ky */
/* loaded from: assets/audience_network.dex */
public final class C1367Ky {
    public static void A00(AbstractRunnableC1363Ku abstractRunnableC1363Ku) {
        new Handler(Looper.getMainLooper()).post(abstractRunnableC1363Ku);
    }
}
