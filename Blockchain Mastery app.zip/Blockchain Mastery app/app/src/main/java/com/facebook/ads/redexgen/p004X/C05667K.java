package com.facebook.ads.redexgen.p004X;

import android.os.Handler;
import android.os.Looper;

/* renamed from: com.facebook.ads.redexgen.X.7K */
/* loaded from: assets/audience_network.dex */
public final class C05667K {
    public Handler A00;

    public C05667K(Looper looper) {
        this.A00 = new Handler(looper);
    }

    public final void A00(RunnableC05677L runnableC05677L) {
        this.A00.post(runnableC05677L);
    }

    public final void A01(RunnableC05677L runnableC05677L) {
        this.A00.removeCallbacks(runnableC05677L);
    }

    public final boolean A02(RunnableC05677L runnableC05677L, long j) {
        return this.A00.postDelayed(runnableC05677L, j);
    }
}
