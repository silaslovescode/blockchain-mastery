package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.1T */
/* loaded from: assets/audience_network.dex */
public class C02071T {
    public String A00;
    public String A01;
    public String A02;
    public String A03;

    public final C02071T A04(String str) {
        this.A00 = str;
        return this;
    }

    public final C02071T A05(String str) {
        this.A01 = str;
        return this;
    }

    public final C02071T A06(String str) {
        this.A02 = str;
        return this;
    }

    public final C02071T A07(String str) {
        this.A03 = str;
        return this;
    }

    public final C02081U A08() {
        return new C02081U(this);
    }
}
