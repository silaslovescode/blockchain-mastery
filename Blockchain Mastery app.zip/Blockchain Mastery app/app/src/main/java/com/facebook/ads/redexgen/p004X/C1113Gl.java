package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.Gl */
/* loaded from: assets/audience_network.dex */
public final class C1113Gl {
    public final int A00;
    public final boolean A01;
    public final byte[] A02;
    public final byte[] A03;

    public C1113Gl(int i, boolean z, byte[] bArr, byte[] bArr2) {
        this.A00 = i;
        this.A01 = z;
        this.A03 = bArr;
        this.A02 = bArr2;
    }
}
