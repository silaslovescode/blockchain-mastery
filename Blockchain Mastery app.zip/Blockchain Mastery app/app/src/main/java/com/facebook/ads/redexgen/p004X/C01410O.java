package com.facebook.ads.redexgen.p004X;

import androidx.annotation.RequiresApi;

@RequiresApi(24)
/* renamed from: com.facebook.ads.redexgen.X.0O */
/* loaded from: assets/audience_network.dex */
public class C01410O extends C01510Y {
}
