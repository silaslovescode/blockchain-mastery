package com.facebook.ads.internal.settings;

/* loaded from: assets/audience_network.dex */
public class AdSdkVersion {
    public static final String BUILD = "6.8.0";
}
