package com.facebook.ads.redexgen.p004X;

import android.view.View;
import androidx.annotation.RequiresApi;

@RequiresApi(19)
/* renamed from: com.facebook.ads.redexgen.X.0d */
/* loaded from: assets/audience_network.dex */
public class C01560d extends C02201g {
    @Override // com.facebook.ads.redexgen.p004X.C1021FF, com.facebook.ads.redexgen.p004X.C030837
    public final void A0C(View view, int i) {
        view.setImportantForAccessibility(i);
    }

    @Override // com.facebook.ads.redexgen.p004X.C030837
    public final boolean A0J(View view) {
        return view.isAttachedToWindow();
    }
}
