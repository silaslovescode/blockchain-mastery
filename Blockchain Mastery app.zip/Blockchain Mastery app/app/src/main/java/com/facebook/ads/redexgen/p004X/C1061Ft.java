package com.facebook.ads.redexgen.p004X;

import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.Ft */
/* loaded from: assets/audience_network.dex */
public final class C1061Ft {
    @Nullable
    public C1061Ft A00;
    @Nullable
    public C1157HV A01;
    public boolean A02;
    public final long A03;
    public final long A04;

    public C1061Ft(long j, int i) {
        this.A04 = j;
        this.A03 = i + j;
    }

    public final int A00(long j) {
        return ((int) (j - this.A04)) + this.A01.A00;
    }

    public final C1061Ft A01() {
        this.A01 = null;
        C1061Ft c1061Ft = this.A00;
        this.A00 = null;
        return c1061Ft;
    }

    public final void A02(C1157HV c1157hv, C1061Ft c1061Ft) {
        this.A01 = c1157hv;
        this.A00 = c1061Ft;
        this.A02 = true;
    }
}
