package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.G8 */
/* loaded from: assets/audience_network.dex */
public class C1074G8 extends AbstractC2514df<Integer> {
    public C1074G8(String str) {
        super(str);
    }
}
