package com.facebook.ads.internal.androidx.support.p002v4.view;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Inherited
@Retention(RetentionPolicy.RUNTIME)
/* renamed from: com.facebook.ads.internal.androidx.support.v4.view.ViewPager$DecorView */
/* loaded from: assets/audience_network.dex */
public @interface ViewPager$DecorView {
}
