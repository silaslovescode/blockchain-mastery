package com.facebook.ads.redexgen.p004X;

import androidx.annotation.RequiresApi;

@RequiresApi(18)
/* renamed from: com.facebook.ads.redexgen.X.1g */
/* loaded from: assets/audience_network.dex */
public class C02201g extends C03323W {
}
