package com.facebook.ads.redexgen.p004X;

import android.annotation.TargetApi;
import android.media.AudioAttributes;
import androidx.annotation.Nullable;

/* renamed from: com.facebook.ads.redexgen.X.BD */
/* loaded from: assets/audience_network.dex */
public final class C0792BD {
    public static final C0792BD A04 = new C0791BC().A00();
    public AudioAttributes A00;
    public final int A01;
    public final int A02;
    public final int A03;

    public C0792BD(int i, int i2, int i3) {
        this.A01 = i;
        this.A02 = i2;
        this.A03 = i3;
    }

    @TargetApi(21)
    public final AudioAttributes A00() {
        if (this.A00 == null) {
            this.A00 = new AudioAttributes.Builder().setContentType(this.A01).setFlags(this.A02).setUsage(this.A03).build();
        }
        return this.A00;
    }

    public final boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        C0792BD c0792bd = (C0792BD) obj;
        return this.A01 == c0792bd.A01 && this.A02 == c0792bd.A02 && this.A03 == c0792bd.A03;
    }

    public final int hashCode() {
        int result = this.A02;
        return (((((17 * 31) + this.A01) * 31) + result) * 31) + this.A03;
    }
}
