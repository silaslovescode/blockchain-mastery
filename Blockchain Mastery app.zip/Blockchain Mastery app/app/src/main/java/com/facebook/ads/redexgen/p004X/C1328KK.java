package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.KK */
/* loaded from: assets/audience_network.dex */
public /* synthetic */ class C1328KK {
    public static final /* synthetic */ int[] A00 = new int[EnumC1329KL.values().length];

    static {
        try {
            A00[EnumC1329KL.A05.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            A00[EnumC1329KL.A09.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            A00[EnumC1329KL.A08.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            A00[EnumC1329KL.A0A.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            A00[EnumC1329KL.A0D.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            A00[EnumC1329KL.A0E.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            A00[EnumC1329KL.A0F.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
        try {
            A00[EnumC1329KL.A0C.ordinal()] = 8;
        } catch (NoSuchFieldError unused8) {
        }
        try {
            A00[EnumC1329KL.A0G.ordinal()] = 9;
        } catch (NoSuchFieldError unused9) {
        }
        try {
            A00[EnumC1329KL.A0J.ordinal()] = 10;
        } catch (NoSuchFieldError unused10) {
        }
        try {
            A00[EnumC1329KL.A0H.ordinal()] = 11;
        } catch (NoSuchFieldError unused11) {
        }
        try {
            A00[EnumC1329KL.A0I.ordinal()] = 12;
        } catch (NoSuchFieldError unused12) {
        }
        try {
            A00[EnumC1329KL.A06.ordinal()] = 13;
        } catch (NoSuchFieldError unused13) {
        }
        try {
            A00[EnumC1329KL.A0B.ordinal()] = 14;
        } catch (NoSuchFieldError unused14) {
        }
    }
}
