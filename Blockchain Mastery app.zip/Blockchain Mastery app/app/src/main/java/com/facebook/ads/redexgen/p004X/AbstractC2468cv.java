package com.facebook.ads.redexgen.p004X;

/* renamed from: com.facebook.ads.redexgen.X.cv */
/* loaded from: assets/audience_network.dex */
public abstract class AbstractC2468cv implements InterfaceC05687M {
    public final boolean A00;

    public abstract void A00();

    public abstract void A01(boolean z);

    public AbstractC2468cv(boolean z) {
        this.A00 = z;
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC05687M
    public final void AAF() {
        if (this.A00) {
            A00();
        } else {
            A01(false);
        }
    }

    @Override // com.facebook.ads.redexgen.p004X.InterfaceC05687M
    public final void AAM() {
        A01(true);
    }
}
