package android.support.p001v4.media.session;

import android.media.session.MediaSession;

/* renamed from: android.support.v4.media.session.f */
/* loaded from: classes.dex */
class C0034f {
    /* renamed from: a */
    public static Object m2655a(Object obj) {
        return ((MediaSession.QueueItem) obj).getDescription();
    }

    /* renamed from: b */
    public static long m2654b(Object obj) {
        return ((MediaSession.QueueItem) obj).getQueueId();
    }
}
