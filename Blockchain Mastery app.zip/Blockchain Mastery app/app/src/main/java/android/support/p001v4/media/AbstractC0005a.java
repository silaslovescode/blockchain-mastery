package android.support.p001v4.media;

import android.os.Bundle;

/* renamed from: android.support.v4.media.a */
/* loaded from: classes.dex */
public abstract class AbstractC0005a {
    /* renamed from: a */
    public abstract void m2740a(String str, Bundle bundle, Bundle bundle2);

    /* renamed from: b */
    public abstract void m2739b(String str, Bundle bundle, Bundle bundle2);

    /* renamed from: c */
    public abstract void m2738c(String str, Bundle bundle, Bundle bundle2);
}
