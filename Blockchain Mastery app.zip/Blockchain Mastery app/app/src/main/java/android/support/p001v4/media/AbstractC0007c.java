package android.support.p001v4.media;

import android.os.Bundle;
import java.util.List;

/* renamed from: android.support.v4.media.c */
/* loaded from: classes.dex */
public abstract class AbstractC0007c {
    /* renamed from: a */
    public abstract void m2735a(String str, Bundle bundle);

    /* renamed from: b */
    public abstract void m2734b(String str, Bundle bundle, List<MediaBrowserCompat$MediaItem> list);
}
