package android.support.p001v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

/* renamed from: android.support.v4.media.f */
/* loaded from: classes.dex */
class C0012f {
    /* renamed from: a */
    public static void m2713a(Object obj, Parcel parcel, int i) {
        ((MediaMetadata) obj).writeToParcel(parcel, i);
    }
}
