package android.support.p001v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: android.support.v4.media.session.ParcelableVolumeInfo */
/* loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new C0017a();

    /* renamed from: d */
    public int f43d;

    /* renamed from: e */
    public int f44e;

    /* renamed from: f */
    public int f45f;

    /* renamed from: g */
    public int f46g;

    /* renamed from: h */
    public int f47h;

    /* renamed from: android.support.v4.media.session.ParcelableVolumeInfo$a */
    /* loaded from: classes.dex */
    static class C0017a implements Parcelable.Creator<ParcelableVolumeInfo> {
        C0017a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a */
        public ParcelableVolumeInfo createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b */
        public ParcelableVolumeInfo[] newArray(int i) {
            return new ParcelableVolumeInfo[i];
        }
    }

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f43d = parcel.readInt();
        this.f45f = parcel.readInt();
        this.f46g = parcel.readInt();
        this.f47h = parcel.readInt();
        this.f44e = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f43d);
        parcel.writeInt(this.f45f);
        parcel.writeInt(this.f46g);
        parcel.writeInt(this.f47h);
        parcel.writeInt(this.f44e);
    }
}
