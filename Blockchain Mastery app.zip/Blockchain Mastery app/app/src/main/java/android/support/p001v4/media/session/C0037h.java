package android.support.p001v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

/* renamed from: android.support.v4.media.session.h */
/* loaded from: classes.dex */
class C0037h {
    /* renamed from: a */
    public static Bundle m2640a(Object obj) {
        return ((PlaybackState) obj).getExtras();
    }
}
