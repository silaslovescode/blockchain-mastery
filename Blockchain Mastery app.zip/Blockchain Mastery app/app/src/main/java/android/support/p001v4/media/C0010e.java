package android.support.p001v4.media;

import android.media.MediaDescription;
import android.net.Uri;

/* renamed from: android.support.v4.media.e */
/* loaded from: classes.dex */
class C0010e {

    /* renamed from: android.support.v4.media.e$a */
    /* loaded from: classes.dex */
    static class C0011a {
        /* renamed from: a */
        public static void m2714a(Object obj, Uri uri) {
            ((MediaDescription.Builder) obj).setMediaUri(uri);
        }
    }

    /* renamed from: a */
    public static Uri m2715a(Object obj) {
        return ((MediaDescription) obj).getMediaUri();
    }
}
