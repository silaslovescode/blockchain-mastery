package android.support.p001v4.media;

/* renamed from: android.support.v4.media.b */
/* loaded from: classes.dex */
public abstract class AbstractC0006b {
    /* renamed from: a */
    public abstract void m2737a(String str);

    /* renamed from: b */
    public abstract void m2736b(MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem);
}
