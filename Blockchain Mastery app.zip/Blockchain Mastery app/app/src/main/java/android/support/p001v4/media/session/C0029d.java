package android.support.p001v4.media.session;

/* renamed from: android.support.v4.media.session.d */
/* loaded from: classes.dex */
public final class C0029d {
    /* JADX INFO: Access modifiers changed from: package-private */
    public C0029d(int i, int i2, int i3, int i4, int i5) {
    }
}
